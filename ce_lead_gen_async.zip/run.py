"""Start the Auto Lead Generation server."""


import auto_lead_generation
from auto_lead_generation import factory, configs

app = factory.create_app(celery=auto_lead_generation.celery)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=configs.PORT_CNFG, debug=configs.DEBUG_CONFIG)
