"""Flask app for Auto Lead Generation."""

import os
import pandas as pd
from flask import (
    jsonify,
    request,
)
from flask import Flask, request, jsonify
import pandas as pd
import auto_lead_generation.utils as utils

app = Flask(__name__)


TEMP_SAVE_DIR = os.path.join(os.getcwd(), "user_uploads/")
TEMPFILE_DIRECTORY = os.path.join(
    os.path.dirname(os.path.realpath(__file__)), "tempfile_dir"
)

@app.route("/postgres/write", methods=["POST"])
def upload_file():
    try:
        file = request.files['file']
        table_name = request.form['table_name']
        if file and table_name:
            if not os.path.isdir(TEMPFILE_DIRECTORY):
                os.makedirs(TEMPFILE_DIRECTORY)
            file_path = os.path.join(TEMPFILE_DIRECTORY, file.filename)
            file.save(file_path)
            df = pd.read_excel(file_path) if file_path.endswith('.xlsx') else pd.read_csv(file_path)
            utils.write_to_postgres(df, table_name)
            return jsonify({'message': 'File uploaded successfully and data written to the database.'})
        else:
            return jsonify({'error': 'Missing file or table_name parameter'}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    

if __name__ == '__main__':
    app.run(debug=True)