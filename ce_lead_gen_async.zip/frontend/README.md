# Introduction 
A simple dash app to visualize the leads generated from the documents. The app has been deployed in https://incubator.marketintelligence.spglobal.com/.
The app can be accessed from: https://incubator.marketintelligence.spglobal.com/AquaLeadGen/

# Getting Started
1. Create a new virtual environment with python version=3.7.7
2. Download the required files in assets folder from the link in readme
3. Update the required information in configs.py
4. Run the app by calling ```python app.py```

# Deploying/Updating the App in Incubator
1. Update the requirements.txt with any new libaries/packages
2. Navigate to the parent folder and run the following command
```rsconnect deploy dash --server https://incubator.marketintelligence.spglobal.com/ --entrypoint app.py --api-key dZ0N4DSe5vJhD4UYc2wUP2nAN9YIFGlw [project_folder_name]```