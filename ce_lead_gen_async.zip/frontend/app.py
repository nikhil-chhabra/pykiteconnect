import base64
import hashlib
import requests
import secrets
from flask import Flask, render_template, redirect, request, session, url_for, send_file
from flask_login import (LoginManager,login_required,login_user,logout_user)
from flask import Flask
from user import User
from dash_app import create_dash_app
from configs import generate_configs
import utils
from db_utils_ui import S3Utils
import os
import configs
import io

def create_app():
    app = Flask(__name__)
    app.config.update({'SECRET_KEY': secrets.token_hex(64)})

    login_manager = LoginManager()
    login_manager.init_app(app)
    login_manager.login_view = "/"
    
    @login_manager.user_loader
    def load_user(user_id):
        return User.get(user_id)

    @app.route("/")
    def home():
        print (request.base_url+"authorization-code/callback")
        return render_template("home.html")

    @app.route("/download/<filename>")
    @login_required
    def download_file(filename):
        try:
            configs=generate_configs(session['app_name'])
        except:
            configs=generate_configs("Commodity Insights")
        parent_url=configs['parent_url']
        s3_filepath=parent_url.format(filename.split('.pdf')[0])
        s3_obj=S3Utils()
        local_file=os.path.basename(s3_filepath)
        pdf=s3_obj.read_document(s3_filepath)
        file = io.BytesIO(pdf)
        return send_file(file, mimetype='application/pdf', as_attachment=False, download_name=local_file)

    @app.route("/login")
    def login():
        # store app state and code verifier in session
        session['app_state'] = secrets.token_urlsafe(64)
        session['code_verifier'] = secrets.token_urlsafe(64)

        # calculate code challenge
        hashed = hashlib.sha256(session['code_verifier'].encode('ascii')).digest()
        encoded = base64.urlsafe_b64encode(hashed)
        code_challenge = encoded.decode('ascii').strip('=')

        # get request params
        query_params = {'client_id': configs.client_id,
                        'redirect_uri': request.base_url+"authorization-code/callback",
                        'scope': "api groups openid profile email address phone",
                        'state': session['app_state'],
                        'code_challenge': code_challenge,
                        'code_challenge_method': 'S256',
                        'response_type': 'code',
                        'response_mode': 'query'}

        # build request_uri
        request_uri = "{base_url}?{query_params}".format(
            base_url=configs.org_url + "oauth2/default/v1/authorize",
            query_params=requests.compat.urlencode(query_params).replace("loginauthorization","authorization")
        )

        return redirect(request_uri)


    # Sample list of accessible apps
    def get_apps_list():
        okta_grp=utils.get_okta_config()
        print (okta_grp.columns)
        accessible_apps = okta_grp[okta_grp['group'].isin(session['user_groups'])]['app'].drop_duplicates().tolist()
        return accessible_apps


    @app.route('/select_lead_gen_ui')
    @login_required
    def select_lead_gen_ui():
        accessible_apps=get_apps_list()
        # Pass the accessible_apps list to the HTML template
        if len(accessible_apps)>1:
            return render_template('app.html', accessible_apps=accessible_apps)
        elif len(accessible_apps)==1:
            session['app_name'] = accessible_apps[0]
            return redirect(url_for('/lead_gen_ui/'))
        else:
            return "You are not authorized to access this application.", 403

    @app.route('/update_session', methods=['GET','POST'])
    @login_required
    def update_session():
        selected_app = request.args.get('app_name')
        print (selected_app)
        session['app_name'] = selected_app
        return redirect(url_for("/lead_gen_ui/"))

    @app.route("/authorization-code/callback")
    def callbacks():
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        code = request.args.get("code")
        # app_state = request.args.get("state")
        # if app_state != session['app_state']:
        #     return "The app state does not match"
        if not code:
            return "The code was not returned or is not accessible", 403
        query_params = {'grant_type': 'authorization_code',
                        'code': code,
                        'redirect_uri': request.base_url,
                        'code_verifier': session['code_verifier'],
                        }
        print (request.base_url)
        query_params = requests.compat.urlencode(query_params)
        exchange = requests.post(
            configs.org_url + "oauth2/default/v1/token",
            headers=headers,
            data=query_params,
            auth=(configs.client_id, configs.client_secret),
        ).json()

        # Get tokens and validate
        if not exchange.get("token_type"):
            return "Unsupported token type. Should be 'Bearer'.", 403
        access_token = exchange["access_token"]
        id_token = exchange["id_token"]
        session['access_token']=access_token
        # Authorization flow successful, get userinfo and login user
        userinfo_response = requests.get(configs.org_url + "oauth2/default/v1/userinfo",
                                        headers={'Authorization': f'Bearer {access_token}'}).json()

        unique_id = userinfo_response["sub"]
        user_email = userinfo_response["email"]
        user_name = userinfo_response["FirstName"] + " " + userinfo_response["LastName"]
        user = User(
            id_=unique_id, name=user_name, email=user_email
        )

        if not User.get(unique_id):
            User.create(unique_id, user_name, user_email)
        session['username'] = user_name
        session['user_groups'] = userinfo_response['SPGGroups']

        login_user(user)
        return redirect(url_for("select_lead_gen_ui"))

    @app.route("/logout", methods=["GET", "POST"])
    @login_required
    def logout():
        logout_user()   
        return redirect(url_for("home"))



    app_dash=create_dash_app(app)

    for view_func in app.view_functions:
        if view_func.startswith(app_dash.config['routes_pathname_prefix']):
            app.view_functions[view_func] = login_required(app.view_functions[view_func])
    
    return app

app=create_app()

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000, debug=True)
