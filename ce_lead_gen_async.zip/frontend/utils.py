import dash_bootstrap_components as dbc
from dash import dcc, html, ctx
import dash_ag_grid as dag
from sqlalchemy import create_engine
import pandas as pd
import datetime
from flask import session
import configs as config_data

def get_okta_config():
    query="SELECT * FROM okta_access_tbl"
    server = config_data.server
    password = config_data.password
    username = config_data.username
    db=config_data.db
    target = "{0}:{1}@{2}".format(username, password, server, db)
    db_engine = create_engine("postgresql+psycopg2://{0}/{1}".format(target,db))
    with db_engine.connect() as db_cxn, db_cxn.begin():
        query_results = pd.read_sql_query(query, db_cxn)
    query_results.columns=['group','app']
    return query_results

def get_saved_filters():
    query='SELECT * FROM saved_filters_tbl'
    server = config_data.server
    password = config_data.password
    username = config_data.username
    db=config_data.db
    target = "{0}:{1}@{2}".format(username, password, server, db)
    db_engine = create_engine("postgresql+psycopg2://{0}/{1}".format(target,db))
    with db_engine.connect() as db_cxn, db_cxn.begin():
        query_results = pd.read_sql_query(query, db_cxn)
    try:
        user=session['username']
        app_name=session['app_name']
        query_results=query_results[(query_results['user']==user)&(query_results['domain']==app_name)]
    except:
         pass
    return query_results

def get_saved_filters_full():
    query='SELECT * FROM saved_filters_tbl'
    server = config_data.server
    password = config_data.password
    username = config_data.username
    db=config_data.db
    target = "{0}:{1}@{2}".format(username, password, server, db)
    db_engine = create_engine("postgresql+psycopg2://{0}/{1}".format(target,db))
    with db_engine.connect() as db_cxn, db_cxn.begin():
        query_results = pd.read_sql_query(query, db_cxn)
    return query_results

def add_saved_filter(df):
    server = config_data.server
    password = config_data.password
    username = config_data.username
    db = config_data.db
    target = "{0}:{1}@{2}".format(username, password, server, db)
    db_engine = create_engine("postgresql+psycopg2://{0}/{1}".format(target,db))
    table="saved_filters_tbl"
    with db_engine.connect() as db_cxn, db_cxn.begin():
        df.to_sql(table,db_cxn,if_exists='append', index=False)

def delete_saved_filter(user,filter,domain):
    df=get_saved_filters_full()
    df=df[(df['user']!=user)|(df['domain']!=domain)|(df['filter_name']!=filter)]
    server = config_data.server
    password = config_data.password
    username = config_data.username
    db = config_data.db
    target = "{0}:{1}@{2}".format(username, password, server, db)
    db_engine = create_engine("postgresql+psycopg2://{0}/{1}".format(target,db))
    table="saved_filters_tbl"
    with db_engine.connect() as db_cxn, db_cxn.begin():
        df.to_sql(table,db_cxn,if_exists='replace', index=False)

def update_saved_filter(df):
    server = config_data.server
    password = config_data.password
    username = config_data.username
    db = config_data.db
    target = "{0}:{1}@{2}".format(username, password, server, db)
    db_engine = create_engine("postgresql+psycopg2://{0}/{1}".format(target,db))
    table="saved_filters_tbl"
    with db_engine.connect() as db_cxn, db_cxn.begin():
        df.to_sql(table,db_cxn,if_exists='replace', index=False)

def postgresql_df(query):
    server = config_data.server
    password = config_data.password
    username = config_data.username
    db = config_data.db
    target = "{0}:{1}@{2}".format(username, password, server, db)
    db_engine = create_engine("postgresql+psycopg2://{0}/{1}".format(target,db))
    with db_engine.connect() as db_cxn, db_cxn.begin():
        query_results = pd.read_sql_query(query, db_cxn)
    return query_results

def write_to_postgres(df,configs):
    server = config_data.server
    password = config_data.password
    username = config_data.username
    db = config_data.db
    target = "{0}:{1}@{2}".format(username, password, server, db)
    db_engine = create_engine("postgresql+psycopg2://{0}/{1}".format(target,db))
    table=configs['table']
    with db_engine.connect() as db_cxn, db_cxn.begin():
        df.to_sql(table,db_cxn,if_exists='replace', index=False)

def build_navbar(configs):
    return dbc.Navbar(
                        dbc.Container(
                            [
                                html.A(
                                    dbc.Row(
                                        [
                                            dbc.Col(html.Img(src='assets/spgmi-logo.png', height="50px", style={'padding-right': '1.9rem'})),
                                            dbc.Col(dbc.NavbarBrand(configs['app_title'], className="ms-4", style={'font-size':'30px'})),
                                        ],
                                        align="left",
                                        className="g-0",
                                    ),
                                    
                                    style={"textDecoration": "none"},
                                ),

                               
                            ],
                        id='nav_container', style={'margin':'10px'}),
                        color='transparent',dark=False,
                    )

def make_buttons():

    return html.Div(
    [
        dbc.Button("Save", id='save-btn', className="me-1"),
        dbc.Button("Reset", id='reset-btn', className="me-1"),
        dbc.Button("Clear Filters", id='reset-ftr-btn', className="me-1"),
        dbc.Button("Download Data", id = 'download-btn', className="me-1 btn2")
    ]
)

def row_count_options():
    
    quick_search=html.Div([
        dbc.Input(id="quick-search", placeholder="Quick search...", type="text", style={'display': 'inline-block', 'margin-left': '10px','margin-top': '15px'})
        ],style={'display': 'inline-block', 'margin-left': '10px'}) 
    
    return dbc.Row([dbc.Col([quick_search]),
                    dbc.Col(['Visible Rows Count: '], style={'margin-top': '15px'}),
                    dbc.Col([dcc.Dropdown([{'label':i,'value':i} for i in [15,50,100]],
                                            id='row-count',
                                            placeholder="Visible rows count..",
                                            multi=False,
                                            searchable=False,
                                            clearable=False,
                                            value=15,
                                            )], style={'text-align': 'start','margin-top': '15px'})
                    ], style={'align-items': 'center','text-align': 'end'})


def build_dropdown(column_list):
        return dcc.Dropdown(column_list, style={'margin-top': '15px'},
                            id='hide-col-dd',
                            placeholder="Select columns to hide..",
                            multi=True,
                            )

def make_aggrid(df,configs):
    
    return dag.AgGrid(
                        id="data-grid",
                        columnDefs= configs['column_def'],
                        enableEnterpriseModules=True,
                        rowData= df.to_dict('records'),
                        className="ag-theme-alpine",
                        columnSize="autoSize",
                        style={'height': '75vh'},
                        getRowId="params.data.document_name",
                        csvExportParams={"fileName": configs['app_title']+'_'+datetime.datetime.now().strftime("%m%d%Y_%H%M%S"),},
                        dashGridOptions={"pagination": True, 'paginationPageSize': 15,"rowSelection": "single" ,"tooltipShowDelay": 0},
                        defaultColDef={ 
                                        "resizable": True,
                                        "cellStyle": {"wordBreak": "normal", "lineHeight": "unset"},
                                        "autoHeight": True,
                                        "wrapText": True,
                                        },
                    )

def confirm_dialog():
    return html.Div(
            [
                dbc.Modal(
                    [
                        dbc.ModalHeader(dbc.ModalTitle("Do you want to save the changes?")),
                        dbc.ModalBody(dcc.Loading(
                                                        id="loading-2",
                                                        children=[html.Div([html.Div(id="loading-output-2")])],
                                                        type="default",
                                                    )),
                        dbc.ModalFooter([dbc.Button(
                                "Yes", id="yes-btn-save", n_clicks=0
                            ),
                            dbc.Button(
                                "No", id="no-btn-save", n_clicks=0
                            )]
                            
                        ),
                    ],
                    id="dialog-save",
                    centered=True,
                    is_open=False,
                ),
            ]
        )

def reset_dialog():
    return html.Div(
            [
                dbc.Modal(
                    [
                        dbc.ModalHeader(dbc.ModalTitle("Do you want to discard the unsaved changes?")),
                        dbc.ModalBody(dcc.Loading(
                                                        id="loading-1",
                                                        children=[html.Div([html.Div(id="loading-output-1")])],
                                                        type="default",
                                                    )),
                        dbc.ModalFooter([dbc.Button(
                                "Yes", id="yes-btn-rst", n_clicks=0
                            ),
                            dbc.Button(
                                "No", id="no-btn-rst", n_clicks=0
                            )]
                            
                        ),
                    ],
                    id="dialog-rst",
                    centered=True,
                    is_open=False,
                ),
            ]
        )

def save_filter_dropdown():
        saved_filters=get_saved_filters()
        saved_filters_list=[]
        for (i,row) in saved_filters.iterrows():
             saved_filters_list.append({'label':row['filter_name'],
                            'value':row['filter_value']})
        save_filter_dropdown=dbc.Row([dbc.Col([dcc.Dropdown(saved_filters_list,id='filter-list-dd',searchable=True, clearable=True, placeholder='Select a saved filter..', style={'margin-top': '15px'})],width=9),
                                       dbc.Col([dbc.Button([html.I(className="bi bi-funnel")], id='filter-edit-btn', className="me-1 btn2", style={'margin-top': '15px'})],width=1)])
        return save_filter_dropdown

def filter_dialog():
    saved_filters=get_saved_filters()
    saved_filters_list=[]
    for (i,row) in saved_filters.iterrows():
            saved_filters_list.append({'label':row['filter_name'],
                        'value':row['filter_value']})
    return html.Div(
            [
                dbc.Modal(
                    [
                        dbc.ModalHeader(dbc.ModalTitle("Edit Saved Filters")),
                        dbc.ModalBody([ dbc.Row([dbc.Col([dbc.Input(id="add-filter-name", placeholder="Type new filter name...", type="text")],width=9),
                                                dbc.Col([dbc.Button("Add", id='filter-add-btn', className="me-1 btn2")],width=1)]),
                                        dbc.Row([dbc.Col([dcc.Dropdown(saved_filters_list,id='filter-list-edit-dd',searchable=True, clearable=True, placeholder='Select a saved filter to delete..', style={'margin-top': '15px'})],width=9),
                                                dbc.Col([dbc.Button("Delete", id='filter-del-btn', className="me-1 btn2", style={'margin-top': '15px'})],width=1)]),
                                        dbc.Row([dcc.Loading(
                                                        id="loading-filter-1",
                                                        children=[html.Div(id="filter-msg",style={'margin-top': '15px'})],
                                                        type="default",
                                                    )]),
                                                ]),
                       

                        
                    ],
                    id="dialog-filter",
                    centered=True,
                    is_open=False,
                ),
            ]
        )