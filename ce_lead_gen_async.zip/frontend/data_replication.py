# -*- coding: utf-8 -*-
"""
Created on Mon Nov 20 21:23:38 2023

@author: NIKHIL_CHHABRA
"""

from sqlalchemy import create_engine
import pandas as pd

def copy_data(source_server,
              un_src,
              pwd_src,
              source_db,
              source_tbl,
              target_server,
              un_tgt,
              pwd_tgt,
              target_db,
              target_tbl):
    
    query="SELECT * FROM "+source_tbl
    target = "{0}:{1}@{2}".format(un_src, pwd_src, source_server)
    db_engine = create_engine("postgresql+psycopg2://{0}/{1}".format(target,source_db))
    with db_engine.connect() as db_cxn, db_cxn.begin():
        query_results = pd.read_sql_query(query, db_cxn)
        
    target = "{0}:{1}@{2}".format(un_tgt, pwd_tgt, target_server)
    db_engine = create_engine("postgresql+psycopg2://{0}/{1}".format(target,target_db))
    with db_engine.connect() as db_cxn, db_cxn.begin():
        query_results.to_sql(target_tbl,db_cxn,if_exists='replace', index=False)
        
    return True




for i,row in df.iterrows():
    break
    source_server=row['source_server']
    un_src=row['un_src']
    pwd_src=row['pwd_src']
    source_db=row['source_db']
    source_tbl=row['source_tbl']
    target_server=row['target_server']
    un_tgt=row['un_tgt']
    pwd_tgt=row['pwd_tgt']
    target_db=row['target_db']
    target_tbl=row['target_tbl']


    copy_data(source_server,un_src,pwd_src, source_db,source_tbl,target_server,un_tgt,pwd_tgt, target_db, target_tbl)



