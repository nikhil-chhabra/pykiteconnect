import pandas as pd
import dash
from dash import html, Input, Output, State, dcc, Patch, clientside_callback
from flask import session, send_file
import dash_bootstrap_components as dbc
from dash import html, Input, Output, callback
import utils
from urllib.parse import quote as urlquote
from configs import generate_configs
from db_utils_ui import S3Utils
import json

def load_default_data(configs):
    # reading the postgres data (add conditions to read source type from configs)
    query="select * from " + configs['table']
    df = utils.postgresql_df(query)
    df['curated_document'] = df['document_name']
    columns=[col['field'] for col in configs['column_def']]
    df=df[columns]
    return df

def get_config():
    try:
        app_name=session['app_name']
    except:
        app_name=""
    try:
        configs=generate_configs(app_name)
    except:
        configs=generate_configs('Indices')

    return configs

def serve_layout():
    configs=get_config()
    df=load_default_data(configs)
    navbar = utils.build_navbar(configs)
    columns_list = []
    for item in configs['column_def']:
        columns_list.append({'label':item['headerName'],
                            'value':item['field']})
    dropdown = utils.build_dropdown(columns_list)
    main_button_row = utils.make_buttons()
    data_table = utils.make_aggrid(df,configs)
    total_rows= html.Div(['Total Rows : ' + str(len(df))],id='tooltip', style={'margin':'2px'})
    content = html.Div([data_table])
    save_confirm_box=utils.confirm_dialog()
    reset_confirm_box=utils.reset_dialog()
    filter_box=utils.filter_dialog()
    row_count_option=utils.row_count_options()
    try:
        name='Welcome, '+ session['username']
    except:
        name=""
    name_elem=html.Div([name],style={'display': 'inline-block'})    
    logout_button=html.Form([dbc.Button("Logout", id='logout-btn', className="me-1")],method='POST',action='/logout',style={'display': 'inline-block', 'margin-left': '10px'})
    save_filter_dropdown=utils.save_filter_dropdown()
    layout = dbc.Container([html.Div([name_elem,logout_button], style={'position': 'absolute', 'top': 10, 'right': 10}), 
                            dbc.Row([navbar,save_confirm_box,reset_confirm_box,filter_box],style={'width':'85%'}), 
                            dbc.Row([dbc.Col([main_button_row],width=3),
                                     dbc.Col([save_filter_dropdown],width=2),
                                     dbc.Col([dropdown],width=3),
                                     dbc.Col([row_count_option],width=4),]),
                            dbc.Row([html.Hr(style={'borderWidth': "0.3vh", "width": "100%", "borderColor": "#cb0028", "opacity": "unset",'margin':'4px'}),]),
                            dbc.Row([html.Div(id='test-text')]),
                            dbc.Row([total_rows]),
                            dbc.Row([content], style = {'height':'65vh'})], fluid=True, id='layout')
    return layout

def create_dash_app(flask_app=True):
    app_dash = dash.Dash(__name__,
                    server=flask_app,
                    external_stylesheets=[dbc.themes.BOOTSTRAP, dbc.icons.BOOTSTRAP],
                    title="Lead Generation Analytics",
                    meta_tags=[{'name': 'viewport','content': 'width=device-width, initial-scale=1, maximum-scale=1.0, minimum-scale=1,'}],
                    url_base_pathname='/lead_gen_ui/')

    app_dash.config.suppress_callback_exceptions = True

    # layout to render the app
    app_dash.layout = serve_layout

    #Callback for download data as csv
    @callback(
        Output("data-grid", "exportDataAsCsv"),
        Input("download-btn", "n_clicks"),
    )
    def export_data_as_csv(n_clicks):
        if n_clicks:
            return True
        return False

    #Callback for hide/unhide columns based on selections via dropdown
    @callback(
        Output("data-grid", "columnState"),
        Input("hide-col-dd", "value"),
        Input("hide-col-dd", "options"),
        prevent_initial_call=True,
    )
    def update_hide(selected,default):
        default=[i['value'] for i in default]
        new_state = [{"colId":col,"hide":True} for col in selected]+[{"colId":col,"hide":False} for col in default if col not in selected]
        return new_state

    # Callback to open save dialog box
    @callback(
        Output("dialog-save", "is_open", allow_duplicate=True),
        [Input("no-btn-save", "n_clicks"), Input("save-btn", "n_clicks")],
        [State("dialog-save", "is_open")],
        prevent_initial_call=True,
    )
    def toggle_save(n1, n2, is_open):
        if n1 or n2:
            return not is_open
        return is_open


    #Callback for updating UI with successful save action.
    @callback(
                Output("tooltip","children"),
                Output("dialog-save", "is_open"),
                Output("loading-output-2", "children"),
                Input("yes-btn-save", "n_clicks"),
                State("data-grid", "rowData"),
                State("dialog-save", "is_open"),
                prevent_initial_call=True,
            )
    def save_grid(n,rowData,is_open):
        configs=get_config()
        updated_df=pd.DataFrame(rowData)
        utils.write_to_postgres(updated_df,configs)
        return ['Total Rows : ' + str(len(updated_df))+' - Data Saved Successfully'],not is_open,""

    # Callback for Reset Button that opens reset dialog box
    @callback(
                    Output("dialog-rst", "is_open", allow_duplicate=True),
                    [Input("no-btn-rst", "n_clicks"), 
                    Input("reset-btn", "n_clicks")],
                    [State("dialog-rst", "is_open")],
                    prevent_initial_call=True,
                )
    def toggle_reset(n1, n2, is_open):
        if n1 or n2:
            return not is_open
        return is_open

    # Callback for resetting unsaved changes on UI
    @callback(Output("data-grid", "rowData"),
            Output("dialog-rst", "is_open"),
            Output("loading-output-1", "children"),
            Input("yes-btn-rst", "n_clicks"),
            State("dialog-rst", "is_open"),
            prevent_initial_call=True,
            )
    def reset_grid(n,is_open):
        configs=get_config()
        df=load_default_data(configs)
        return df.to_dict('records'),not is_open,""

    #Callback for adjusting number of items on individual page based on input via a button group with options 10/50/100 (Currently disabled due to performance lag with higher values.)
    @callback(Output("data-grid", "dashGridOptions",allow_duplicate=True),
            Input("row-count", "value"),
            prevent_initial_call=True,
            )
    def row_button(value):
        return {"pagination": True, 'paginationPageSize': value,"tooltipShowDelay": 0}
    
    # Callback for Updating Username on Row update.
    @callback(
    Output("data-grid", "rowTransaction"),
    Input("data-grid", "cellValueChanged"),
    State("data-grid", "selectedRows"),
    prevent_initial_call=True,
    )
    def update_name(cell_data,selection):
        for row in selection:
            row["user"] = session['username']
        return {"update": selection}

    # Callback for Clearing All Filters
    @callback(
    Output("data-grid", "filterModel",allow_duplicate=True),
    Output("filter-list-dd", "value"),
    Input("reset-ftr-btn", "n_clicks"),
    prevent_initial_call=True,
    )
    def get_cur_filter(n):
        return [{},None]

    # Callback for quick filter
    @callback(
    Output("data-grid", "dashGridOptions"), Input("quick-search", "value"),prevent_initial_call=True,
    )
    def update_filter(filter_value):
        return {'quickFilterText': filter_value, "rowSelection": "single","tooltipShowDelay": 0}
    
    # Callback for updating filter based on selected filter out of saved filters dropdown
    @callback(
    Output("data-grid", "filterModel"), 
    Input("filter-list-dd", "value"),
    prevent_initial_call=True,
    )
    def filtermodel(filter):
        if filter:
            return json.loads(filter.replace("'",'"'))
        else:
            return {}

    
    
    # Callback to open save dialog box
    @callback(
        Output("dialog-filter", "is_open", allow_duplicate=True),
        [Input("filter-edit-btn", "n_clicks")],
        [State("dialog-filter", "is_open")],
        prevent_initial_call=True,
    )
    def toggle_filters(n2, is_open):
        if n2:
            return not is_open
        return is_open

    # Callback for adding new filter
    @callback(Output("filter-msg","children", allow_duplicate=True),
              Output("filter-list-dd","options", allow_duplicate=True),
              Output("filter-list-edit-dd","options", allow_duplicate=True),
            Input("filter-add-btn", "n_clicks"),
            State("data-grid", "filterModel"),
            State("add-filter-name","value"),
            State("filter-list-dd","options"),
            prevent_initial_call=True,)
    def add_filter(n,filter,name,filter_list):
        if n:
            filter_name=name
            filter_value=str(filter)
            user=session['username']
            domain=session['app_name']
            df=utils.get_saved_filters()
            if filter_name in df['filter_name'].tolist():
                return ["Filter name already exists.",filter_list,filter_list]
            else:
                new_filter=[{'user':user,
                            'filter_name':filter_name,
                            'filter_value':str(filter_value),
                            'domain':domain}]
                new_filter_df=pd.DataFrame(new_filter)
                df_update=pd.concat([df,new_filter_df])
                utils.add_saved_filter(new_filter_df)
                saved_filters_list=[]
                for (i,row) in df_update.iterrows():
                    saved_filters_list.append({'label':row['filter_name'],
                                'value':row['filter_value']})
                return [("Filter "+filter_name+" added successfully."),saved_filters_list,saved_filters_list]
            
    # Callback for deleting a saved filter
    @callback(Output("filter-msg","children"),
              Output("filter-list-dd","options"),
              Output("filter-list-edit-dd","options"),
            Input("filter-del-btn", "n_clicks"),
            State("filter-list-edit-dd", "value"),
            State("filter-list-edit-dd", "options"),
            prevent_initial_call=True, )
    def delete_filter(n,selected_value,dropdown_options):
        if n:
            for option in dropdown_options:
                if option['value'] == selected_value:
                    selected_label = option['label']
                    break
            user=str(session['username'])
            domain=str(session['app_name'])
            df=utils.get_saved_filters()
            df=df[df['filter_name']!=str(selected_label)]
            utils.delete_saved_filter(user,str(selected_label),domain)
            saved_filters_list=[]
            for (i,row) in df.iterrows():
                saved_filters_list.append({'label':row['filter_name'],
                            'value':row['filter_value']})
            return [("Filter "+str(selected_label)+" deleted successfully."),saved_filters_list,saved_filters_list]



    return app_dash

if __name__=='__main__':
    app=create_dash_app()
    app.run(debug=True)