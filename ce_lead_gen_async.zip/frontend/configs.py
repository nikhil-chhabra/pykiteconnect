import re

server = 'incubator-db-2.cpx9jdg3dlsj.us-east-1.rds.amazonaws.com:5432'
password = 'HelloSpgMiNPD123!'
username = 'postgres'
db='lead_generation'


org_url='https://spglobal.okta.com/'
client_id='0oad398zibAAIjnzg5d7'
client_secret='NsfOxO9rZPIPOWZxw4Lq1AEQ-lfFyH2agSTgtksNndgjQCFgegTMVVFVXkCnmtx4'

f = open(r"C:\Users\nikhil_chhabra\.aws\credentials", "r")
text=f.read()
lll=re.findall('=(.*?)(?:\r?\n|$)',text)
AWS_ACCESS_KEY_ID = lll[2].strip()
AWS_SECRET_KEY_ACCESS = lll[3].strip()
AWS_SESSION_TOKEN = lll[4].strip()
BUCKET_NAME = "s3-mi-dt-rxlead-dev-us-east-1"
AWS_REGION = "us-east-1"

# def generate_configs(domain):
#     import boto3
#     import os
#     import json

#     """Download config file from S3"""
#     access_key_id = AWS_ACCESS_KEY_ID
#     session = boto3.Session(
#                     aws_access_key_id = access_key_id,
#                     aws_secret_access_key = AWS_SECRET_KEY_ACCESS,
#                     aws_session_token=AWS_SESSION_TOKEN,
#                     region_name = AWS_REGION
#                 )
#     s3 = session.resource('s3')
#     s3_bucket = s3.Bucket(BUCKET_NAME)
#     s3_filepath='ui_configs/'+domain+'.json'
#     local_file=os.path.basename(s3_filepath)
#     # Get file path from URI
#     if s3_filepath.startswith("s3:"):
#         s3_filepath = s3_filepath.split(BUCKET_NAME + '/')[1]
    
#     # Download file
#     s3_bucket.download_file(s3_filepath, local_file)
#     configs_file = open(local_file)
#     json_data = configs_file.read()
#     configs_dict = json.loads(json_data)
#     return configs_dict

#############################################################################################
def generate_configs(domain):
    # from sqlalchemy import create_engine
    # import pandas as pd
    # import json
    # query="SELECT config FROM configs_ui_tbl where domain = '"+domain+"'"
    # target = "{0}:{1}@{2}".format(username, password, server, db)
    # db_engine = create_engine("postgresql+psycopg2://{0}/{1}".format(target,db))
    # with db_engine.connect() as db_cxn, db_cxn.begin():
    #     query_results = pd.read_sql_query(query, db_cxn)
    # json_data=query_results.iloc[0,0]
    # configs_dict = json.loads(json_data)
    import json
    configs_file = open('ui_configs/'+domain+'.json')
    json_data = configs_file.read()
    configs_dict = json.loads(json_data)
    return configs_dict
    