# -*- coding: utf-8 -*-
"""
Created on Fri Dec  1 20:29:55 2023

@author: nikhil_chhabra
"""

from sqlalchemy import create_engine
import pandas as pd
import configs as config_data
from urllib.parse import quote as urlquote
from urllib.request import urlretrieve
import os
def postgresql_df(query):
    server = config_data.server
    password = config_data.password
    username = config_data.username
    db = config_data.db
    target = "{0}:{1}@{2}".format(username, password, server)
    db_engine = create_engine("postgresql+psycopg2://{0}/{1}".format(target,db))
    with db_engine.connect() as db_cxn, db_cxn.begin():
        query_results = pd.read_sql_query(query, db_cxn)
    return query_results

df=postgresql_df('select * from indices_results')

def upload_to_s3(s3_filepath,file):
    import requests
    
    url = "https://hub-workers-rx-lead-generation-ns.eks-stage-us-east-1.container.spglobal.com/s3-operator"
    
    payload = {'operator': 'upload',
    'path': s3_filepath}
    files=[
      ('file',(file,open(file,'rb'),'application/json'))
    ]
    headers = {}
    
    response = requests.request("POST", url, headers=headers, data=payload, files=files)
    
    print(response.text)

def push_to_stage(doc):
    url='https://incubator.marketintelligence.spglobal.com/indices_api/download/?file={}_concised.pdf'.format(urlquote(doc.split('.pdf')[0]))
    filename='{}_concised.pdf'.format(urlquote(doc.split('.pdf')[0]))
    s3_filepath='LeadGeneration/outputs/pdfs/Indices/'+filename
    urlretrieve(url,filename)
    upload_to_s3(s3_filepath,filename)
    os.remove(filename)

df['document_name'].apply(push_to_stage)
