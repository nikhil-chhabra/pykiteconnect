# Introduction 
Auto Lead generation async pipeline 

# Release Notes

## TBD
- Added ability to upload a file and process it in real time. To test the app or for a demo run, navigate to `localhost:8082/flash-annotate`
- Code formatting & cleanup

## 21-09-2023
- Added proximity parameter in the config that defines how the association is to be considered in proximity of - block, page or document
- Updated color code mapping based on association instead of pattern
- Added excellent association (having snp_500 and benchmark_related patterns) at block level and trademark association at document level
- Code cleanup


# Getting Started
This run needs docker and postman setup in the local machine

# Steps for local run

In terminal - 
1. Git clone “git path of repo”
2. python -m venv .venv
3. source .venv/bin/activate
4. pip install -r requirements.txt
5. docker pull redis
6. docker run -d -p 6379:6379 redis:latest 

In another terminal to run task1_queue- 
1. source .venv/bin/activate
2. celery -A celery_worker.celery worker -O fair -Q task1_queue 

In another terminal to run task2_queue- 
1. source .venv/bin/activate
2. celery -A celery_worker.celery worker -O fair -Q task2_queue 

In another terminal to run python code- 
1. source .venv/bin/activate
2. python run.py

In another terminal to run flower-
1. source .venv/bin/activate
2. celery -A celery_worker.celery flower --port=5555

Input required for local run -
1. add config.json file having pattern configuration in "pattern_config_file/config.json"
2. create output folder in local machine, which is used as input of below API 
3. after running all terminals as above, run below APIs with the inputs as mentioned-

## 1st API run 

To get annotated documents in output_folder - http://localhost:8082/bulk_run/run

This API needs 2 inputs - 
{
"input_docfolder":"local_path_to_input_folder_having_documents",
"output_docfolder":"local_path_to_output_folder_to_save_annotated_documents"
}

## 2nd API run 

To get excel result - http://localhost:8082/excel_from_json/run

This API needs 1 input-
{

"output_docfolder":"local_path_to_output_folder_to_save_excel_result_file"

}


