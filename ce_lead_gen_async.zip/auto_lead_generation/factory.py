"""Initialize the Flask/Celery backend."""

import os
from flask import Flask
from flask_cors import CORS

from kombu import Queue

from auto_lead_generation.celery_utils import init_celery
from auto_lead_generation import configs


PKG_NAME = os.path.dirname(os.path.realpath(__file__)).split("/")[-1]


def create_app(app_name=PKG_NAME, **kwargs):
    """Initialize the flask app."""
    app = Flask(app_name)
    CORS(app)

    app.config.update(
        broker_url=configs.celery_broker_url,
        result_backend=configs.celery_result_backend,
        result_expires=configs.celery_result_expires,
        task_time_limit=configs.celery_task_time_limit,
        worker_prefetch_multiplier=configs.celery_worker_prefetch_multiplier,
    )

    # defining queues
    app.config.tasks_queues = (
        Queue("task1_queue", exchange="task1_queue", routing_key="task1_queue"),
        Queue("task2_queue", exchange="task2_queue", routing_key="task2_queue"),
    )

    if kwargs.get("celery"):
        init_celery(kwargs.get("celery"), app)

    from auto_lead_generation.views import bp

    app.register_blueprint(bp)

    return app
