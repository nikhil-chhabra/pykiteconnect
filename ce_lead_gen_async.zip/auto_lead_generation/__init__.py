from celery import Celery
import auto_lead_generation.configs as configs


def make_celery(app_name=__name__):
    """
    Creates celery object
    """
    return Celery(
        app_name,
        backend=configs.celery_result_backend,
        broker=configs.celery_broker_url,
    )


celery = make_celery()
