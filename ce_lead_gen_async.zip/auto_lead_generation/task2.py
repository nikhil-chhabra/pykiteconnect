"""Task to Annotate a PDF."""


import json
import os
import uuid
import db_utils
from auto_lead_generation.task1 import read_doc
from db_utils import S3Utils
import pandas as pd
import numpy as np
import logging
from auto_lead_generation.celery_app import logger
import auto_lead_generation.configs as configs


if configs.loglevel.upper().strip() == 'DEBUG': 
    logger.setLevel(logging.DEBUG)
elif configs.loglevel.upper().strip() == 'INFO':
    logger.setLevel(logging.INFO)
else:
    logger.setLevel(logging.CRITICAL)

def update_hits(hits):
    hits_list = [list(ele) for ele in hits]
    column_names = [
        "Proximity",
        "Document Name",
        "Association",
        "Pattern",
        "Page",
        "Block No",
        "Block Type",
        "x0",
        "y0",
        "x1",
        "y1",
    ]

    # Create a DataFrame with all 11 columns and fill missing values with NaN
    df = pd.DataFrame(
        [hit + [np.nan] * (len(column_names) - len(hit)) for hit in hits_list],
        columns=column_names,
    )
    df1 = df[(df["Association"] == "snp_core")]
    df2 = df[(df["Association"] == "rating")]
    list_of_lists = []
    if (len(df1) != 0) & (len(df2) != 0):
        group_df1 = (
            df1.groupby(
                by=[
                    "Document Name",
                    "Association",
                    "Page",
                    "Block No",
                    "x0",
                    "y0",
                    "x1",
                    "y1",
                ]
            )["Association"]
            .apply(lambda x: x.notnull().any())
            .reset_index(name="irrelevant")
        )
        group_df2 = (
            df2.groupby(
                by=[
                    "Document Name",
                    "Association",
                    "Page",
                    "Block No",
                    "x0",
                    "y0",
                    "x1",
                    "y1",
                ]
            )["Association"]
            .apply(lambda x: x.notnull().any())
            .reset_index(name="irrelevant")
        )
        comb_df = pd.merge(
            group_df1,
            group_df2,
            on=[
                "Document Name",
                "Page",
                "Block No",
                "x0",
                "y0",
                "x1",
                "y1",
                "irrelevant",
            ],
        )
        comb_df = comb_df[
            ["Document Name", "Page", "Block No", "x0", "y0", "x1", "y1", "irrelevant"]
        ]
        not_highlight = comb_df[comb_df["irrelevant"] == True][
            ["Page", "Block No", "x0", "y0", "x1", "y1"]
        ]

        merged = pd.merge(
            df,
            not_highlight,
            on=["Page", "Block No", "x0", "y0", "x1", "y1"],
            how="left",
            indicator=True,
        )

        # Filter out rows that are in df2
        result_df = merged[merged["_merge"] == "left_only"].drop(columns="_merge")
        result_df = result_df.drop(
            result_df[result_df["Association"] == "rating"].index
        )

        list_of_lists = result_df.values.tolist()

    if list_of_lists:
        hits_final = list_of_lists
    else:
        df = df.drop(df[df["Association"] == "rating"].index)
        hits_final = df.values.tolist()

    return hits_final


def annotator(doc, hits, docpath, colors, task_id):
    """Wrapper function for `Single Document`.

    - Calls get_hits function internally
    - if hits > 0 then cretes rectangles on block using coordinates
    - additionally uses colors dict to highlight rectangle by category
    - then finally trims the pages to 0-5 + pages with lead
    - lastly, calls save_file function to save to S3
    """

    logger.info(f"[{task_id}]: {docpath} processed successfully.")  ## LOG ##

    if len(hits) > 0:
        logger.info(f"[{task_id}]: {docpath} getting highlighted")
        req_pages = []
        hits = [inner_list for inner_list in hits if len(inner_list) == 11]
        hits = [inner_list for inner_list in hits if inner_list[0] == "block"]

        for (
            _,
            _,
            assoc,
            _,
            page,
            _,
            _,
            x0,
            y0,
            x1,
            y1,
        ) in list(hits):
            pg = doc.load_page(int(page))
            rect = [x0, y0, x1, y1]

            highlight = pg.add_rect_annot(rect)

            color_list = []
            if assoc in colors:
                for color_code in colors[assoc]:
                    color_list.append(color_code / 255.0)

                highlight.set_colors(stroke=color_list)
                highlight.update()

                req_pages.append(int(page))
        if doc.page_count >= 6:
            keep_pages = list(sorted(set(list(range(0, 5)) + req_pages)))
        else:
            keep_pages = list(range(doc.page_count))

        try:
            doc.select(keep_pages)
            return doc

        except Exception as ex:  ## pylint:disable=broad-except
            logger.error(f"[{task_id}]: Failed to annotate {docpath}")
            pass


def save_file_local(doc, docpath, output_docfolder):
    """Save to local path, invoked by save_file function."""
    save_file_path = output_docfolder + os.path.basename(docpath)[:-4] + "_concised.pdf"
    doc.save(save_file_path, garbage=3)

    logger.info(f"ANNOTATED: {save_file_path} saved to LOCAL successfully.")  ## LOG ##


def save_doc(doc, output_docfolder):
    """Saves a PDF doc to the given path (currently S3)."""

    S3Utils("LeadGeneration").save_document(output_docfolder, doc.write())


def task2_func(docpath, output_docfolder, project_config, domain, hits_folder, bucket, task_id):
    """Reads document-specific Hits JSON to annotate based on user-given color code."""

    project_path = "/".join(docpath.split("/")[-1:]).split(".", maxsplit=1)[0] + ".json"
    # print(project_path)

    hits_save_path = os.path.join(hits_folder, project_path)

    ## TODO: Handle try/except, let it by-pass with conditions (if/else)

    hits_result = json.loads(
        db_utils.S3Utils("LeadGeneration").read_document(hits_save_path)
    )
    logger.info(f"[{task_id}] : Hits loaded from {hits_save_path}")

    hits = list(tuple(x) for x in hits_result)
    if domain == "Indices":
        hits = update_hits(hits)

    doc = read_doc(docpath, bucket, task_id)

    if not project_config:
        ## TODO: Open project-specific default config.
        with open("pattern_config_file/config.json", "r") as config_json:
            project_config = json.load(config_json)

    colors = project_config["colors"]

    annotated_doc = annotator(doc, hits, docpath, colors, task_id)
    output_folder = output_docfolder + os.path.basename(docpath).replace('.pdf','') + "_concised.pdf"
    save_doc(annotated_doc, output_folder)
    logger.info(f"[{task_id}] : File annotated and saved to {output_folder}")
