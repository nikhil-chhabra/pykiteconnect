"""Async tasks for Lead Generation."""


import json
import os
import uuid
import pandas as pd
from bson import json_util
from datetime import datetime
import pytz
import auto_lead_generation.configs as configs
import db_utils
from auto_lead_generation import celery
from auto_lead_generation.task1 import task1_func
from auto_lead_generation.task2 import task2_func
import auto_lead_generation.utils as utils
import logging
from auto_lead_generation.celery_app import logger


if configs.loglevel.upper().strip() == 'DEBUG': 
    logger.setLevel(logging.DEBUG)
elif configs.loglevel.upper().strip() == 'INFO':
    logger.setLevel(logging.INFO)
else:
    logger.setLevel(logging.CRITICAL)

## TODO: Create pipeline where input is VersionID and output is bulk_run.
UTC = pytz.utc

@celery.task(
    bind=True,
    track_started=True,
    task_time_limit=configs.chain_task_hard_time_limit,
    max_retries=configs.leadgen_worker_max_retries,
)
def register_bulk_task(self, **kwargs):
    """Runs the LeadGen pipeline for a large volume of files."""

    s3_files = kwargs["s3_files_list"]
    count_files=len(s3_files)
    logger.info(f"[{self.request.id}] : Number of files to process: {count_files}" )

    project_config = kwargs["project_config"]
    output_docfolder = kwargs["output_docfolder"]
    hits_folder = kwargs["hits_folder"]
    domain = kwargs["domain"]
    try:
        bucket_name = s3_files[0]['s3_paths'].split("/")[0]
    except:
        bucket_name=None
    bulk_task_id= kwargs["bulk_task_id"]
    project_name=kwargs["project_name"]
    logger.info(f"[{self.request.id}] : Bucket name: {bucket_name}")

    for document in s3_files:
        doc_task_id=str(uuid.uuid4())
        try:
            leadgen_async_task.apply_async(
                kwargs={
                    "docpath": document['s3_paths'],
                    "output_docfolder": output_docfolder,
                    "hits_folder": hits_folder,
                    "project_config": project_config,
                    "domain": domain,
                    "bucket": bucket_name,
                    "bulk_task_id": bulk_task_id,
                    "task_id":doc_task_id,
                    "project_name":project_name,
                    "versionid":document['versionid']
                }, 
                task_id=doc_task_id
            )

        except Exception as e:  ## pylint:disable=broad-except
            logger.error(f"[{self.request.id}] : Error while executing task: {e}")
    logger.info(f"[{self.request.id}] : Finished registering tasks")


@celery.task(
    bind=True,
    track_started=True,
    task_reject_on_worker_lost=True,
    task_time_limit=configs.leadgen_worker_hard_time_limit,
    max_retries=configs.leadgen_worker_max_retries,
    queue="leadgen_queue",
)
def leadgen_async_task(self, **kwargs):
    """Asynchronously gets hits from a document and saves the respective annotations."""

    try:
        start_time=datetime.now(UTC)
        project_name=kwargs["project_name"]
        versionid=kwargs["versionid"]
        s3_path=kwargs["docpath"]
        domain=kwargs["domain"]
        task_id=kwargs['task_id']
        bulk_task_id=kwargs['bulk_task_id']
        logger.info(f"[{self.request.id}] : Getting hits for the document {s3_path}")
        document_hits = task1_func(
            kwargs["docpath"],
            kwargs["project_config"],
            kwargs["domain"],
            kwargs["bucket"],
            kwargs["task_id"]
        )
        

        if document_hits:
            hits_json = json.dumps(document_hits, default=json_util.default)
            logger.info(f"[{self.request.id}] : Finished getting hits for document {s3_path}")

            ## TODO: Make project_path creation more readable.
            project_path = (
                "/".join(kwargs["docpath"].split("/")[-1:]).split(".", maxsplit=1)[0]
                + ".json"
            )

            hits_save_path = os.path.join(kwargs["hits_folder"], project_path)
            logger.info(f"[{self.request.id}] : Saving hits for document {s3_path} to {hits_save_path}")

            db_utils.S3Utils("LeadGeneration").save_document(hits_save_path, hits_json)
            logger.info(f"[{self.request.id}] : Hits saved for document {s3_path} to {hits_save_path}")

            ## TODO: Log to DB.

            ## Start Task 2
            task2_func(
                kwargs["docpath"],
                kwargs["output_docfolder"],
                kwargs["project_config"],
                kwargs["domain"],
                kwargs["hits_folder"],
                kwargs["bucket"],
                kwargs["task_id"]
            )

            logger.info(f"[{self.request.id}] : Finished executing document annotation for document {s3_path}")
            status="success"
            lead_strength=utils.get_lead_strength(document_hits,domain)
            error=None
            hits_found=True
            end_time=datetime.now(UTC)
            data={"task_id":task_id,
                  "bulk_task_id":bulk_task_id,
                  "versionid":versionid,
                  "s3_path":s3_path,
                  "start_time":start_time,
                  "end_time":end_time,
                  "domain":domain,
                  "project_name":project_name,
                  "hits_found":hits_found,
                  "lead_strength":lead_strength,
                  "status":status,
                  "error":error,
                  }
            utils.task_run_summary_to_db(data)
        else:
            logger.info(f"[{self.request.id}] : No hits for document {s3_path} found")
            status="success"
            error=None
            hits_found=False
            lead_strength=None
            end_time=datetime.now(UTC)
            data={"task_id":task_id,
                  "bulk_task_id":bulk_task_id,
                  "versionid":versionid,
                  "s3_path":s3_path,
                  "start_time":start_time,
                  "end_time":end_time,
                  "domain":domain,
                  "project_name":project_name,
                  "hits_found":hits_found,
                  "lead_strength":lead_strength,
                  "status":status,
                  "error":error,
                  }
            utils.task_run_summary_to_db(data)

    except Exception as e:  ## pylint:disable=broad-except
        # exponential delay in retries
        if self.request.retries==configs.leadgen_worker_max_retries:
            logger.error(f"[{self.request.id}] : Document {s3_path} failed - {e}")
            project_name=kwargs["project_name"]
            versionid=kwargs["versionid"]
            s3_path=kwargs["docpath"]
            domain=kwargs["domain"]
            task_id=kwargs['task_id']
            bulk_task_id=kwargs['bulk_task_id']
            status="fail"
            error=str(e)
            try:
                if document_hits:
                    hits_found=True
                else:
                    hits_found=False
            except:
                hits_found=None
            lead_strength=None
            end_time=datetime.now(UTC)
            data={"task_id":task_id,
                "bulk_task_id":bulk_task_id,
                "versionid":versionid,
                "s3_path":s3_path,
                "start_time":start_time,
                "end_time":end_time,
                "domain":domain,
                "project_name":project_name,
                "hits_found":hits_found,
                "lead_strength":lead_strength,
                "status":status,
                "error":error,
                }
            utils.task_run_summary_to_db(data)
        self.retry(**kwargs, countdown=3**self.request.retries)


@celery.task(
    bind=True,
    track_started=True,
    task_time_limit=configs.task1_hard_time_limit,
    max_retries=configs.task1_max_retries,
    queue="task1_queue",
)
def async_task1(self, **kwargs):
    """Background task to gets hits and dump them as json for a document."""
    try:
        print(f"Started getting hits for the document, task id: {self.request.id}")
        task_uuid = str(self.request.id)
        all_hits = task1_func(
            kwargs["docpath"],
            kwargs["project_config"],
            task_uuid,
            kwargs["domain"],
            kwargs["bucket"],
        )

        # print(type(all_hits))
        # print(kwargs["docpath"])

        if all_hits:
            out_json1 = json.dumps(all_hits, default=json_util.default)
            print(f"Finished getting hits for task id: {self.request.id}")

            project_path = (
                "/".join(kwargs["docpath"].split("/")[-1:]).split(".", maxsplit=1)[0]
                + ".json"
            )
            # print(project_path)

            hits_save_path = os.path.join(kwargs["hits_folder"], project_path)
            print(hits_save_path)

            db_utils.S3Utils().save_document(hits_save_path, out_json1)

            return out_json1
        else:
            print("got no hits for this document")

    except Exception:  ## pylint:disable=broad-except
        # exponential delay in retries
        self.retry(**kwargs, countdown=3**self.request.retries)


@celery.task(
    bind=True,
    track_started=True,
    task_time_limit=configs.task2_hard_time_limit,
    max_retries=configs.task2_max_retries,
    queue="task2_queue",
)
def async_task2(self, **kwargs):
    """Background task to annotate documents."""
    print(f"Started executing document annotation, task id: {self.request.id}")
    try:
        task2_func(
            kwargs["docpath"],
            kwargs["output_docfolder"],
            kwargs["project_config"],
            kwargs["task2_id"],
            kwargs["domain"],
            kwargs["hits_folder"],
            kwargs["bucket"],
        )
        print(f"Finished executing document annotation, task id: {self.request.id}")

    except Exception:  ## pylint:disable=broad-except
        # exponential delay in retries
        self.retry(**kwargs, countdown=3**self.request.retries)
