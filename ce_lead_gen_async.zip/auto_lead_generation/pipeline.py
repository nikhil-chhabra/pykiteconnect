"""Core functions for Auto Lead Generation."""


import logging
import time
import uuid
from multiprocessing import Process
from celery.result import AsyncResult

from auto_lead_generation import celery, configs
from auto_lead_generation.tasks import (  # pylint: disable=unused-import
    async_task1,
    async_task2,
)
from db_utils import S3Utils


def run_task1(task_id, docpath, project_config, domain):
    """Runs task1."""
    try:
        celery.signature(
            "auto_lead_generation.tasks.async_task1",
            kwargs={
                "docpath": docpath,
                "project_config": project_config,
                "domain": domain,
            },
            task_id=task_id,
        ).apply_async(queue="task1_queue")

        return True

    except Exception as ex:  # pylint:disable=broad-except
        logging.exception("Error while creating task1 job: %s", ex)
        return False


def get_task1_result(task_id):
    """Retrieves task result."""

    try:
        logging.info("Getting result of Task (1) ID: %s", task_id)
        _task = AsyncResult(id=task_id, task_name="tasks.async_task1", app=celery)

        return _task.get(), 200
    except BaseException as base_exception:  # pylint:disable=broad-except
        logging.info(
            "Error while getting task1 result for ID %s: %s", task_id, base_exception
        )
        return f"Failed to return result of the following task: {task_id}.", 400


def get_task_status(task_id, task_name):
    """Retrieves async task status"""

    _task = AsyncResult(id=task_id, task_name=task_name, app=celery)
    return _task.task_id, _task.state


def run_task2(task_id, task2_id, docpath, output_docfolder, project_config, domain):
    """Runs task2."""

    try:
        celery.signature(
            "auto_lead_generation.tasks.async_task2",
            kwargs={
                "docpath": docpath,
                "output_docfolder": output_docfolder,
                "project_config": project_config,
                "task2_id": task2_id,
                "domain": domain,
            },
            task_id=task_id,
        ).apply_async(queue="task2_queue")
        logging.info("Task ID for task1 in run_task2: %s", task2_id)

        return True

    except BaseException as base_exception:  # pylint:disable=broad-except
        logging.exception("Failed to create task2 job: %s", base_exception)
        return False


def run_pipeline(docpath, output_docfolder, project_config, domain):
    """this function runs task1+task2 APIs for a document"""

    ## Task 1
    start_time = time.time()
    task1_id = str(uuid.uuid4())

    task1_status = run_task1(
        task_id=task1_id, docpath=docpath, project_config=project_config, domain=domain
    )
    logging.info("Task 1 (run) Status: %s", task1_status)

    current_task_id, status = get_task_status(
        task_id=task1_id, task_name="tasks.async_task1"
    )
    logging.info("Task 1 with ID: %s (Celery) Status %s: ", current_task_id, status)

    while status not in ["SUCCESS", "FALURE"]:
        current_task_id, status = get_task_status(
            task_id=task1_id, task_name="tasks.async_task1"
        )
        logging.info("Task 1 with ID: %s (Celery) Status %s: ", current_task_id, status)
        time.sleep(int(configs.task1_get_request_sleep))

    if status != "SUCCESS":
        status = "FAILED"
    else:
        status = "SUCCESS"

    end_time = time.time() - start_time
    logging.info("Task 1 with ID %s took %s seconds.", task1_id, round(end_time, 4))

    ## Task 2
    task_id = str(uuid.uuid4())
    _ = run_task2(
        task_id=task_id,  ## Task 2 ID
        task2_id=task1_id,  ## Task 1 ID
        docpath=docpath,
        output_docfolder=output_docfolder,
        project_config=project_config,
        domain=domain,
    )

    return task1_id, task_id, status


def run_pipeline_all(input_path, output_path, project_config):
    """this function runs task1+task2 APIs for all documents in loop"""
    s3_input_filepaths = S3Utils().get_file_list(input_path)
    s3_output_filepaths = S3Utils().get_file_list(output_path)
    for s3_input_filepath, s3_output_filepath in (
        s3_input_filepaths,
        s3_output_filepaths,
    ):
        docpath = s3_input_filepath
        output_docfolder = s3_output_filepath.split(".")[0] + "_concised.pdf"
        run_pipeline(docpath, output_docfolder, project_config)


def run_pipeline_parallel(
    filepath, output_docfolder, hits_folder, project_config, domain, bucket
):
    """Runs task1 and task2 as chained tasks."""
    task_id = str(uuid.uuid4())
    try:
        celery.signature(
            "auto_lead_generation.tasks.async_chain_task",
            kwargs={
                "filepath": filepath,
                "output_docfolder": output_docfolder,
                "hits_folder": hits_folder,
                "project_config": project_config,
                "domain": domain,
                "bucket": bucket,
            },
            task_id=task_id,
        ).apply_async(queue="task2_queue")
        logging.info("Task ID for chain_task: %s", task_id)

    except BaseException as base_exception:  # pylint:disable=broad-except
        logging.exception("Failed to create chain task job: %s", base_exception)
    return task_id
