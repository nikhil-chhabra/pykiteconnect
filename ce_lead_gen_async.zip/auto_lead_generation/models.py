"""Contains model information for Swagger documentation."""
