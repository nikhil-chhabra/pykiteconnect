import os
import boto3
import auto_lead_generation.configs as configs

class S3Utils():

    def __init__(self):
        # S3 credentials
        self.bucket_name = configs.BUCKET_NAME
        self.access_key_id = configs.AWS_ACCESS_KEY_ID
        session = boto3.Session(
                        aws_access_key_id = self.access_key_id,
                        aws_secret_access_key = configs.AWS_SECRET_KEY_ACCESS,
                        region_name = configs.AWS_REGION
                    )
        
        self.s3 = session.resource('s3')
        self.s3_bucket = self.s3.Bucket(self.bucket_name)

        if self.access_key_id is None:
            self.ids = 'id="' + configs.canonical_id_mi_content + '",id="' + configs.canonical_id_mi_internal + '"'

        return

    def get_file_list(self, path):
        """Function to get list of all files in a dir of S3"""
        objs = list(self.s3_bucket.objects.filter(Prefix=path))
        return [str(obj.key) for obj in objs]

    def upload(self, input_path, out_path):
        """Function to upload file to S3"""
        # Get file path from URI
        if out_path.startswith("s3:"):
            out_path = out_path.split(self.bucket_name + '/')[1]

        if (os.path.isfile(input_path)) and (out_path != ""):
            if self.access_key_id is not None:
                self.s3.meta.client.upload_file(Filename = input_path, Bucket = self.bucket_name, Key = out_path)
            else:
                self.s3.meta.client.upload_file(Filename = input_path, Bucket = self.bucket_name, Key = out_path, ExtraArgs={'GrantFullControl': self.ids})
        else:
            raise Exception('File to upload not found!')

        s3_uri = 's3://{0}/{1}'.format(self.bucket_name, out_path)
        return s3_uri
    
    def download(self, file_path, download_path):
        """Funciton to download a file from S3"""

        # Get file path from URI
        if file_path.startswith("s3:"):
            file_path = file_path.split(self.bucket_name + '/')[1]
        
        # Download file
        self.s3_bucket.download_file(file_path, download_path)

        return
    
    
    
    def delete(self, file_path):
        """Delete a file from S3"""
        # Get file path from URI
        if file_path.startswith("s3:"):
            file_path = file_path.split(self.bucket_name + '/')[1]

        self.s3.meta.client.delete_object(Bucket = self.bucket_name, Key = file_path)
        
        return
    