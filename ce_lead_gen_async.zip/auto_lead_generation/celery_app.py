from celery import Celery
from celery.utils.log import get_task_logger    
from auto_lead_generation import configs
from auto_lead_generation.mylogger import PostgresHandler
import ssl
import logging
from sqlalchemy import create_engine

app = Celery(
    "app",
    broker=configs.celery_broker_url,
    backend=configs.celery_result_backend,
    include=["app.tasks"],
)

# Other configurations
app.conf.update(
    result_expires=configs.celery_result_expires,
    broker_use_ssl={"ssl_cert_reqs": ssl.CERT_NONE},
    redis_backend_use_ssl={"ssl_cert_reqs": ssl.CERT_NONE},
)

server = configs.server
password = configs.password
username = configs.username
db = configs.db
target = "{0}:{1}@{2}".format(username, password, server)
db_engine = create_engine("postgresql+psycopg2://{0}/{1}".format(target,db))


logger = get_task_logger(__name__)
postgres_handler = PostgresHandler(connection=db_engine, table_name="logs")
logger.addHandler(postgres_handler)


if __name__ == "__main__":
    app.start()
