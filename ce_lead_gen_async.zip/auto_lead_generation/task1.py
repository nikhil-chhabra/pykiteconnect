"""Lead Generation Task 1 (getting hits)."""

import itertools
import json
import os
import fitz
import regex as re
import json
from db_utils import S3Utils
import logging
from auto_lead_generation.celery_app import logger
import auto_lead_generation.configs as configs

#add logging to the code
if configs.loglevel.upper().strip() == 'DEBUG': 
    logger.setLevel(logging.DEBUG)
elif configs.loglevel.upper().strip() == 'INFO':
    logger.setLevel(logging.INFO)
else:
    logger.setLevel(logging.CRITICAL)

def skipword_search(pdf_text, skip_keyword):
    word_check_regex = re.compile(r"\b%s\b" % skip_keyword, re.I)
    return re.search(word_check_regex, pdf_text)


def search_phrase(phrase, text, domain, keywords_to_skip, ignorecase=True):
    """Use regex to check for a word in a text."""
    if domain == "Indices":
        if ignorecase == True:
            if (
                (phrase == "S&P")
                | (phrase == "Standard & Poor's")
                | (phrase == "Dow Jones")
                | (phrase == "S&P 500")
                | (phrase == "S&P 500®")
                | (phrase == "Standard & Poor’s®")
                | (phrase == "S&P®")
                | (phrase == "Dow Jones®")
            ):
                word_check = re.compile(
                    rf"{re.escape(phrase)}(?!\u00AE| 500| Dow Jones Indices| indices)",
                    re.I,
                )

            else:
                word_check = re.compile(r"\b%s\b" % phrase, re.I)

        else:
            if (
                (phrase == "S&P")
                | (phrase == "Standard & Poor's")
                | (phrase == "Dow Jones")
                | (phrase == "S&P 500")
                | (phrase == "S&P 500®")
                | (phrase == "Standard & Poor’s®")
                | (phrase == "S&P®")
                | (phrase == "Dow Jones®")
            ):
                word_check = re.compile(rf"{re.escape(phrase)}(?!\u00AE| 500| Dow Jones Indices| indices)")

            else:
                word_check = re.compile(r"\b%s\b" % phrase)
    else:

        ## Check for patterns to skip
        if keywords_to_skip:
            for word in keywords_to_skip:
                search_result = skipword_search(text, word)
                if search_result:
                    return

        escaped_phrase = re.escape(phrase)
        regex = r"\b" + escaped_phrase + r"(?!\u00AE)\b"

        if ignorecase:
            word_check = re.compile(regex, re.I)
        else:
            word_check = re.compile(regex)

    return re.search(word_check, text)


def read_doc(docpath, bucket, task_id):
    """
    Function to read *single document* in fitz.
    On failure, returns exception
    """

    try:
        pdf_bytes = S3Utils(bucket).read_document(docpath)
        doc = fitz.open("pdf", pdf_bytes)
        logger.info(f"[{task_id}] : File {docpath} read successfully")
        return doc

    except Exception as e:  ## pylint:disable=broad-except
        logger.error(f"[{task_id}] : Error while reading file {docpath} : {e}")
        return None


def get_hits(doc, docpath, patterns, associations, conditions, proximity, domain, skip_patterns, task_id):
    """Primary pattern search function on a `Single Document`.

    - reads document from doc path
    - loops over each page, over each block, over each category, over each phrase
    - calls search_phrase over each phrase and block
    - while applying search_phrase, applies any conditions mentioned in conditions dict
    - cascading appends and flattens to get any hits to doc level
    """
    logger.info(f"[{task_id}] : Task 1 started for {docpath}")
    all_hits = []

    dochits = []
    for pgno, page in enumerate(doc):  # Iterate pages
        pagehits = []
        for block in page.get_text("blocks", sort=False):  # Iterate blocks
            (
                x0,
                y0,
                x1,
                y1,
                block_content,
                block_number,
                block_type,
            ) = block  # unpack a block

            block_content = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\xa0\n]", " ", block_content)  # clean text

            if block_type == 0:  # run only for text based blocks
                blockhits = []

                for k, v in associations.items():
                    cathits = []
                    for category in itertools.chain.from_iterable(v):  # Iterate categories
                        #### CONDITIONS ###
                        ignorecase = True if "ignorecase" in conditions[category] else False
                        #### END ####

                        ## Get list of words that have to be skipped based on the category
                        keywords_to_skip = skip_patterns.get(category, None)

                        for phrase in patterns.get(category):  # Iterate phrases
                            # print(phrase,block_content)
                            hit = search_phrase(
                                phrase,
                                block_content,
                                domain,
                                keywords_to_skip=keywords_to_skip,
                                ignorecase=ignorecase,
                            )

                            if hit != None:
                                cathits.append(
                                    (
                                        os.path.basename(docpath),
                                        phrase,
                                        category,
                                        pgno,
                                        block_number,
                                        block_type,
                                        x0,
                                        y0,
                                        x1,
                                        y1,
                                    )
                                )

                    hit_categories = set([hit[2] for hit in cathits])

                    for v1 in v:
                        if set(v1).issubset(hit_categories):
                            blockhits.append(
                                (
                                    os.path.basename(docpath),
                                    k,
                                    set(v1),
                                    pgno,
                                    block_number,
                                    block_type,
                                    x0,
                                    y0,
                                    x1,
                                    y1,
                                )
                            )

                if len(blockhits) > 0:
                    for (
                        docname,
                        assoc,
                        category,
                        page,
                        block,
                        blocktype,
                        x0,
                        y0,
                        x1,
                        y1,
                    ) in blockhits:
                        if "block" in proximity[assoc]:
                            all_hits.append(
                                (
                                    "block",
                                    docname,
                                    assoc,
                                    category,
                                    page,
                                    block,
                                    blocktype,
                                    x0,
                                    y0,
                                    x1,
                                    y1,
                                )
                            )
                    pagehits.append(blockhits)

        if len(pagehits) > 0:
            pagehits = [i for j in pagehits for i in j]
            hit_categories = set()
            for hit in pagehits:
                hit_categories = hit_categories.union(hit[2])

            for k, v in associations.items():
                for v1 in v:
                    if ("page" in proximity[k]) & (set(v1).issubset(hit_categories)):
                        all_hits.append(("page", docname, k, set(v1), page))

            dochits.append(pagehits)

    if len(dochits) > 0:
        dochits = [i for j in dochits for i in j]

        hit_categories = set()
        for hit in dochits:
            hit_categories = hit_categories.union(hit[2])

        for k, v in associations.items():
            for v1 in v:
                if ("document" in proximity[k]) & (set(v1).issubset(hit_categories)):
                    all_hits.append(("document", docname, k, set(v1)))

    # dochits = [(t[0], t[1], tuple(t[2]), *t[3:]) for t in dochits]
    all_hits = [(t[0], t[1], t[2], tuple(t[3]), *t[4:]) for t in all_hits]

    return all_hits


def task1_func(docpath, project_config, domain, bucket, task_id):
    """Gets hits in a document."""
    ## TODO: Load project-default config file when not provided by the user.
    if not project_config:
        with open("pattern_config_file/config.json", "r") as config_json:
            project_config = json.load(config_json)

    associations = project_config["associations"]
    patterns = project_config["patterns"]
    conditions = project_config["conditions"]
    proximity = project_config["proximity"]

    if domain == "RX":
        skip_patterns = project_config["skip_patterns"]
    else:
        skip_patterns = None

    doc = read_doc(docpath, bucket, task_id)
    if not doc:
        return None
    return get_hits(doc, docpath, patterns, associations, conditions, proximity, domain, skip_patterns, task_id)
