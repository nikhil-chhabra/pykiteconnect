# Import necessary modules
import logging

# Define custom logging handler for PostgreSQL
class PostgresHandler(logging.Handler):
    def __init__(self, connection, table_name):
        super().__init__()
        self.connection = connection
        self.table_name = table_name

    def emit(self, record):
        from celery._state import get_current_task
        task = get_current_task()
        task_id=task.request.id
        task_name=task.name
        try:
            with self.connection.connect() as db_cxn:
                db_cxn.execute(
                    f"INSERT INTO {self.table_name} (task_id,task_name,level, message) VALUES (%s,%s,%s, %s)",
                    (task_id,task_name,record.levelname, record.msg)
                )
        except Exception as e:
            print("Error occurred while logging to PostgreSQL:", e)

