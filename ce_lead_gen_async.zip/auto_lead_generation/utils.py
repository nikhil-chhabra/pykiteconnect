"""Utility/helper functions for LeadGen."""

from sqlalchemy import create_engine
import pandas as pd
import os
import logging
import auto_lead_generation.configs as config_data

ALLOWED_EXTENSIONS = {"json", "pdf"}


def allowed_file(filename):
    """Checks if uploaded file has a valid extension."""
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def check_and_save(path_to_check, object_to_save):
    """Checks if a user-uploaded file exists, then saves accordingly."""
    if not os.path.exists(path_to_check):
        logging.info("New Save path detected, saving file..")
        object_to_save.save(path_to_check)
    else:
        logging.info("File %s already exists, not saving..", path_to_check)

def write_to_postgres(df,table_name):
    server = config_data.server
    password = config_data.password
    username = config_data.username
    db = config_data.db
    target = "{0}:{1}@{2}".format(username, password, server)
    db_engine = create_engine("postgresql+psycopg2://{0}/{1}".format(target,db))
    with db_engine.connect() as db_cxn, db_cxn.begin():
        df.to_sql(table_name,db_cxn,if_exists='replace', index=False)

def bulk_run_summary_to_db(data):
    df=pd.DataFrame([data])
    server = config_data.server
    password = config_data.password
    username = config_data.username
    db = config_data.db
    target = "{0}:{1}@{2}".format(username, password, server)
    db_engine = create_engine("postgresql+psycopg2://{0}/{1}".format(target,db))
    with db_engine.connect() as db_cxn, db_cxn.begin():
        df.to_sql("bulk_run_summary_tbl",db_cxn,if_exists='append', index=False)

def get_task_run_summary():
    query="SELECT * FROM task_run_summary_tbl"
    server = config_data.server
    password = config_data.password
    username = config_data.username
    db = config_data.db
    target = "{0}:{1}@{2}".format(username, password, server)
    db_engine = create_engine("postgresql+psycopg2://{0}/{1}".format(target,db))
    with db_engine.connect() as db_cxn, db_cxn.begin():
        df=pd.read_sql(query, db_cxn)
    return df

def task_run_summary_to_db(data):
    df=pd.DataFrame([data])
    server = config_data.server
    password = config_data.password
    username = config_data.username
    db = config_data.db
    target = "{0}:{1}@{2}".format(username, password, server)
    db_engine = create_engine("postgresql+psycopg2://{0}/{1}".format(target,db))
    # try:
    #     with db_engine.connect() as db_cxn, db_cxn.begin():
    #         query="SELECT * FROM task_run_summary_tbl"
    #         existing_df=pd.read_sql(query, db_cxn)
    #         if data['task_id'] in existing_df['task_id'].tolist():
    #             existing_df=existing_df[existing_df['task_id']!=data['task_id']]
    #         df_final=pd.concat([existing_df,df])
    #         df_final.to_sql("task_run_summary_tbl",db_cxn,if_exists='replace', index=False)
    # except:
    with db_engine.connect() as db_cxn, db_cxn.begin():
        df.to_sql("task_run_summary_tbl",db_cxn,if_exists='append', index=False)


def check_and_map(pattern, my_list):
    if pattern in my_list:
        return 'yes'
    else:
        return 'no'

def get_lead_strength(hits,domain):
    hits1 = [tuple(x) for x in hits]              
    f = 0
    for d in hits1:
        if(len(d)==11):
            f = 1
            break    
    if(f==1):
        column_names = ['Proximity', 'Document Name', 'Association', 'Pattern', 'Page', 'Block No', 'Block Type', 'x0', 'y0', 'x1', 'y1']
        # Create a DataFrame from the flattened data with specified column names
    else:
        column_names = ['Proximity', 'Document Name', 'Association', 'Pattern']
    df = pd.DataFrame(hits1, columns=column_names)

    if(domain == 'Indices'):
        df_strength = df[(df['Association']=='strong')|(df['Association']=='medium')|(df['Association']=='weak')|(df['Association']=='excellent')]
        df_new = df_strength.groupby(by = ['Document Name','Association'])['Pattern'].agg(sum).reset_index()
        sortbox = {'excellent':1,'strong':2,'medium':3,'weak':4}
        df_new['sort_column'] = df_new.Association.map(sortbox)
        #  #sort with sort_column
        df_new = df_new.sort_values('sort_column').drop('sort_column',axis=1).reset_index(drop=True)
        score_df = df_new.groupby(by = 'Document Name').first().reset_index()
        # score_df = df_new[0:1]
        df_comp = df_new.groupby(by = ['Document Name'])['Pattern'].agg(sum).reset_index(name = 'All patterns')
        df_comp['Competitor'] = df_comp['All patterns'].apply(lambda x: check_and_map('competitor_related',x))
        score_df['Competitor'] = df_comp['Competitor']
        
        report_list = ['trademark']
        report_df = df[df['Association'].isin(report_list)]
        merge_df = pd.concat([score_df,report_df], ignore_index=True)
        merge_df_no_duplicates = merge_df.drop_duplicates(subset=['Document Name','Association'])
        merge_df_no_duplicates['Trademark_col'] = merge_df_no_duplicates['Association'].apply(lambda x: 'yes' if x == 'trademark' else 'no')
        
        merge_df_no_duplicates['Trademark'] = merge_df_no_duplicates.groupby('Document Name')['Trademark_col'].transform(lambda x: 'yes' if 'yes' in x.values else 'no')
        
        final_df = merge_df_no_duplicates[(merge_df_no_duplicates['Association']=='strong') |
                                         (merge_df_no_duplicates['Association']=='medium') |
                                          (merge_df_no_duplicates['Association']=='weak')]
        final_df = final_df[["Document Name","Association","Competitor","Trademark"]]
        score_df = final_df.copy().rename(columns={'Association': 'Lead Strength'})
                
    else:
        sortbox = {'strong':1,'medium':2,'weak':3}
    
         #create new column with the sort order
        df_strength = df[(df['Association']=='strong')|(df['Association']=='medium')|(df['Association']=='weak')]
    
    
        df_new = df_strength.groupby(by = ['Document Name','Association'])['Pattern'].agg(sum).reset_index()
        df_new['sort_column'] = df_new.Association.map(sortbox)
        #  #sort with sort_column
    
        df_new = df_new.sort_values('sort_column').drop('sort_column',axis=1).reset_index(drop=True)
        score_df = df_new.groupby(by = 'Document Name').first().reset_index()
        score_df = score_df[['Document Name','Association']]
    
    if len(score_df)==0:
        lead_strength = 'No lead found'
        return lead_strength
    else:
        lead_strength=score_df.reset_index().loc[0,'Association']
        return lead_strength