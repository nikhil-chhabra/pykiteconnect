from auto_lead_generation.s3utils import S3Utils
import auto_lead_generation.configs as configs

import pytz
import os
from datetime import datetime
import pandas as pd
from sqlalchemy import create_engine,text

UTC = pytz.utc
FORMAT = '%Y-%m-%d %H:%M:%S'
DATE_FORMAT = '%Y-%m-%d'
s3_obj = S3Utils()

def call_query(version_id_list):
    chunk_size = 20000
    input_chunks = [version_id_list[i:i + chunk_size] for i in range(0, len(version_id_list), chunk_size)]
    query_results = pd.DataFrame()

    for chunk in input_chunks:
        query_server = configs.query_server
        query_server_username = configs.query_server_username
        query_server_password = configs.query_server_password

                
        query_sql = """select SNPVersionID as versionId, KeyFileVersion from Publish2..FileVersionMap
                                                            where SNPVersionID in :version_ids
                                                            and updOperation < 2"""                                                                                                     
                                                                                                                                                        
        # establish connection
        target = "{0}:{1}@{2}".format(str(query_server_username), str(query_server_password), str(query_server))
        
        
        db_engine = create_engine("mssql+pymssql://{0}/".format(target))
        
        with db_engine.connect() as db_cxn, db_cxn.begin():
            query = text(query_sql)
            query_results_part = pd.read_sql_query(query, db_cxn,params={"version_ids": chunk})
            
        query_results=pd.concat([query_results,query_results_part])

    return query_results



    
def remove_old_files(curr_date, directory):
    """Function to remove old files from directory"""
    for filename in os.listdir(directory):
        try:
            old_date = datetime.strptime(filename.split('_')[0], DATE_FORMAT).replace(tzinfo = UTC)
            if (curr_date - old_date).days > 0:
                os.remove(os.path.join(directory, filename))
        except Exception as _e:
            print(_e)
            print('Ignoring', filename)
    return


def s3_utility_function(input_path, path_2, operator):
    """Utility function for S3 operations"""
    if operator.startswith('down'):
        # Generate directory if not present already
        if not os.path.isdir(path_2):
            os.makedirs(path_2)
        # Remove old files
        curr_date = datetime.now(UTC)
        remove_old_files(curr_date, path_2)

        # Create a file_id
        filename = curr_date.strftime(DATE_FORMAT) + '_' + os.path.basename(input_path)
        download_path = os.path.join(path_2, filename)

        # Download file
        s3_obj.download(input_path, download_path)
        return filename

    elif operator.startswith('up'):
        # Upload file
        s3_uri = s3_obj.upload(input_path, path_2)
        # Delete local file occurrence
        os.remove(input_path)
        return s3_uri

    elif operator.startswith('del'):
        # Delete file
        s3_obj.delete(input_path)
        return input_path

    else:
        return 'Incorrect operator passed'
    
def get_s3_filepaths(excel_df):
    if "s3_paths" in excel_df.columns.tolist():
        excel_df.drop(columns=['s3_paths'],inplace=True)
    """Function to get s3 filepaths from version id via call_query"""
    if configs.RUN_ENV == "LOCAL":
        S3_VERSION_ID_MAP_LOCATION = os.getenv("S3_VERSION_ID_MAP_LOCATION") ## Defaults to None
    
    else:
        S3_VERSION_ID_MAP_LOCATION = configs.S3_VERSION_ID_MAP_LOCATION
   
    version_id = list(excel_df['versionId'].astype(str))
    out_df = call_query(version_id)
    out_df['KeyFileVersion'] = out_df['KeyFileVersion'].apply(lambda x : str(x).replace("-", ""))
    out_df['s3_paths'] = out_df['KeyFileVersion'].apply(lambda x : x)
    filepath_list = pd.merge(excel_df,out_df[['versionId','s3_paths']], on='versionId', how='left')
    return filepath_list

