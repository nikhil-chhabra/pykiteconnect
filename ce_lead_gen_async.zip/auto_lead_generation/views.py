"""Flask app for Auto Lead Generation."""


import io
import json
import logging
import os
import time
import uuid
from datetime import datetime
import pytz
import pandas as pd
from flask import (
    Blueprint,
    jsonify,
    render_template,
    request,
    send_file,
    send_from_directory,
)

import auto_lead_generation.configs as configs
import auto_lead_generation.utils as utils
from auto_lead_generation import celery  # pylint: disable=unused-import
from auto_lead_generation.pipeline import (
    get_task1_result,
    get_task_status,
    run_pipeline,
    run_task1,
    run_task2,
)
from auto_lead_generation.result_excel import get_excel
from auto_lead_generation.tasks import (  # pylint: disable=unused-import
    async_task1,
    async_task2,
)
from auto_lead_generation.utility_functions import get_s3_filepaths, s3_utility_function
from db_utils import S3Utils

bp = Blueprint("views", __name__, template_folder="../frontend/")
logging.getLogger().setLevel(logging.INFO)
TEMP_SAVE_DIR = os.path.join(os.getcwd(), "user_uploads/")
TEMPFILE_DIRECTORY = os.path.join(
    os.path.dirname(os.path.realpath(__file__)), "tempfile_dir"
)

UTC = pytz.utc
@bp.route("/", methods=["GET"])
def index():
    """Landing page for Auto Lead Generation."""
    return (
        f"<p>Thanks for using Auto Lead Generation APIs!</p>"
        f"<p><small>(version: {configs.RELEASE_VERSION})</small></p>"
    )


# Endpoint for task1
@bp.route("/task1/run", methods=["PUT"])
def start_task1():
    """instantiate task1 - saving hits(locally) from document

    input - document path"""

    if not request.json:
        return "This end point is expecting a json request!", 400

    req_data = request.get_json()
    task1_id = str(uuid.uuid4())
    logging.info("Task ID % created.", task1_id)

    status = run_task1(
        task_id=task1_id, docpath=req_data["docpath"], project_config=None
    )

    if status:
        return jsonify(
            {
                "status": status,
                "message": f"A task with ID {task1_id} was started.",
                "status_code": 202,
            }
        )

    return jsonify(
        {"status": False, "status_code": 400, "message": "Failed to start a job."}
    )


@bp.route("/task1/result/<task_id>", methods=["GET"])
def task1_result(task_id):
    """Retrieves async task result"""
    result, status_code = get_task1_result(task_id)
    return jsonify({"result": result, "status_code": status_code})


@bp.route("/task1/status/<task_id>", methods=["GET"])
def task1_status(task_id):
    """Retrieves async task status"""
    response = get_task_status(task_id=task_id, task_name="tasks.async_task1")
    return jsonify(response)


# Endpoint for task2 pipeline
@bp.route("/task2/run/<task_id>", methods=["PUT"])
def start_task2(task_id):
    """instantiate task2 - saving annotated document(locally) from hits received in task1

    input - document path, output folder, task id"""

    if not request.json:
        return "This end point is expecting a json request!", 400

    task2_id = str(task_id)
    task_id = str(uuid.uuid4())
    req_data = request.get_json()

    status = run_task2(
        task_id, task2_id, req_data["docpath"], req_data["output_docfolder"], None
    )
    if status:
        return jsonify(
            {
                "status": status,
                "message": f"A task with ID {task_id} was started.",
                "status_code": 202,
            }
        )

    return jsonify(
        {"status": False, "status_code": 400, "message": "Failed to start a job."}
    )


@bp.route("/task2/status/<task_id>", methods=["GET"])
def task2_status(task_id):
    """Retrieves async task status"""
    response = get_task_status(task_id=task_id, task_name="tasks.async_task2")
    return jsonify(response)


# Endpoint for Adhoc Pipeline Run
@bp.route("/pipeline/run", methods=["PUT"])
def adhoc_run_pipeline():
    """ "instantiate task1+task2 run for a single file

    input - document path, output folder"""

    if not request.json:
        return "This end point is expecting a json request!", 400
    req_data = request.get_json()

    try:
        task1_id, _, status = run_pipeline(
            req_data["docpath"], req_data["output_docfolder"], None
        )
        logging.info("Task %s completed with status %s", task1_id, status)

        return (
            f"A task job with the following job ID {task1_id} ran with status {status}",
            200,
        )

    except BaseException as ex:  # pylint:disable=broad-except
        logging.info("Error while running pipeline: %s", ex)
        return "Pipeline Run task failed!", 400


@bp.route("/bulk_run/run", methods=["POST"])
def bulk_run():
    if request.method == "POST":
        start_time=datetime.now(UTC)
        project_name = request.form.get("project_name", None)
        s3_filepaths_csv = request.files["s3_filepath"] or None
        config_file = request.files["config_file"] or None
        domain_name = request.form.get("domain", None)

        if not any([project_name, s3_filepaths, config_file, domain_name]):
            return jsonify(
                {
                    "message": "Some inputs are missing",
                    "status_code": 400,
                }
            )

        ## TODO: Read files in the register_bulk_task function.
        ## Currently, kombu.exceptions.EncodeError: Object of type FileStorage
        ## is not JSON serializable.
        s3_paths_df = pd.read_csv(s3_filepaths_csv)
        s3_paths_df=get_s3_filepaths(s3_paths_df)
        doc_files = s3_paths_df[['versionId','s3_paths']]
        doc_files.columns=['versionid','s3_paths']
        doc_files=doc_files.to_dict(orient="records")

        project_config = json.loads(config_file.read())
        output_folder = configs.S3_SAVE_LOCATION + "/" + project_name + "/"
        hits_folder = configs.S3_HITS_SAVE_LOCATION + "/" + project_name + "/"
        bulk_task_id = str(uuid.uuid4())

        try:
            celery.signature("auto_lead_generation.tasks.register_bulk_task",
                            kwargs={
                                "s3_files_list": doc_files,
                                "output_docfolder": output_folder,
                                "hits_folder": hits_folder,
                                "project_config": project_config,
                                "project_name":project_name,
                                "domain": domain_name,
                                "bulk_task_id":bulk_task_id,
                            },
                            task_id=bulk_task_id,
                            ).apply_async(queue="leadgen_queue")

            end_time=datetime.now(UTC)

            data={'id': bulk_task_id,
            'start_time':start_time,
            'end_time':end_time,
            'count_docs':len(doc_files),
            'domain':domain_name,
            'project_name':project_name,
            'status':"success",
            'error':None}
            
            utils.bulk_run_summary_to_db(data)
        
        except Exception as e:
            end_time=datetime.now(UTC)

            data={'id': bulk_task_id,
            'start_time':start_time,
            'end_time':end_time,
            'count_docs':len(doc_files),
            'domain':domain_name,
            'project_name':project_name,
            'status':"fail",
            'error':str(e)}
            
            utils.bulk_run_summary_to_db(data)

        return "Run started for all files", 200

    return "Invalid request", 400


@bp.route("/flash-annotate", methods=["GET"])
def flash_annotate():
    """Landing page for Auto Lead Generation."""

    if request.method == "GET":
        return render_template("landing.html")


## TODO(Yash): Read files (PDF, config.json) without saving them in /tmp/ folder
@bp.route("/process_download", methods=["POST"])
def process_download():
    """Processes a file and sends it to the user as a download."""

    """
        1. Run 1D endpoint: Take a single file, upload it, return single S3 CSV (param to download otherwise return CSV in-memory)
            - Download CSV
        2. Run 1A (bulk_run) on this CSV along with other params 
        3. Write file status check, return in this f(x) natively
    """

    if request.method == "POST":
        ## TODO: Error on +1 files
        project_name = request.form.get("project_name", None).lower().strip()
        pdf_file = request.files["file"] or None
        config_file = request.files["config"] or None

        if not all(
            [project_name, pdf_file, config_file]
        ):  ## change to any after testing
            return jsonify(
                {
                    "message": "Either the project name, the \
                                PDF or the config JSON file is missing",
                    "status_code": 400,
                }
            )

        pdf_filename = pdf_file.filename.strip()
        config_filename = config_file.filename.strip()
        config_file = json.loads(config_file.read())

        ## Check if uploaded files are valid/allowed.
        if not all(
            [utils.allowed_file(pdf_filename), utils.allowed_file(config_filename)]
        ):
            return jsonify(
                {
                    "message": "Uploaded files are invalid.",
                    "status_code": 400,
                }
            )

        logging.info("Project Name: %s, PDF Filename: %s", project_name, pdf_filename)

        user_input_save_location = os.path.join(
            configs.S3_FLASHANNOTATE_SAVE_LOCATION, project_name, pdf_filename
        )

        output_folder = os.path.join(
            configs.S3_FLASHANNOTATE_SAVE_LOCATION,
            project_name,
            pdf_filename.split(".")[0] + "_concised.pdf",
        )

        logging.info("Input save location: %s", user_input_save_location)
        logging.info("Output folder: %s", output_folder)

        ## Saving to S3
        S3Utils("LeadGeneration").save_document(
            user_input_save_location, pdf_file.read()
        )

        _, task2_id, _ = run_pipeline(
            docpath=user_input_save_location,
            output_docfolder=output_folder,
            project_config=config_file,
        )

        status = get_task_status(task2_id, "tasks.async_task2")

        while status != "SUCCESS":
            _, status = get_task_status(task2_id, "tasks.async_task2")
            if status == "FAILURE":
                logging.info("Task 2 failed")
                return "No annotations found in this file for the given configuration"
            time.sleep(5)  ## Check status of task2 every 5 seconds
            logging.info("Task 2 status: %s", status)

        concised_pdf = S3Utils("LeadGeneration").download_to_user(output_folder)
        # if status != "SUCCESS":
        #     return "No annotations found in this file for the given configuration"

        # else:
        return send_file(
            concised_pdf,
            download_name=pdf_filename,
        )



@bp.route("/final_excel/run", methods=["POST"])
def final_excel():
    """function to get final score based on the hits"""

    metadata_path = request.files["metadata_csv"] or None
    language_path = request.files["language_csv"] or None
    project_name = request.form.get("project_name", None)
    domain = request.form.get("domain", None)

    metadata_df = pd.read_csv(metadata_path)

    language_df = pd.read_csv(language_path)

    try:
        result_db = get_excel(metadata_df, language_df, project_name, domain)
        return send_file(
            io.BytesIO(result_db.to_csv(index=False, encoding="utf-8").encode()),
            attachment_filename=f"{project_name}.csv",
            as_attachment=True,
        )

    except BaseException as base_exception:  # pylint:disable=broad-except
        logging.exception("Excel not created: %s", base_exception)
        return "Excel not created", 400
    
@bp.route("/final_excel/run_v2", methods=["POST"])
def final_excel_v2():
    """function to get final score based on the hits"""

    metadata_path = request.files["metadata_csv"] or None
    language_path = request.files["language_csv"] or None
    project_name = request.form.get("project_name", None)

    metadata_df = pd.read_csv(metadata_path)

    language_df = pd.read_csv(language_path)
    try:
        metadata_df = pd.merge(metadata_df,language_df[['languageId','languageName']],left_on = 'originalLanguageID',right_on = 'languageId')
        metadata_df = metadata_df.drop(columns = ['originalLanguageID','languageId'])
    except:
        metadata_df['languageName']=""
    task_df=utils.get_task_run_summary()

    try:
        result_db = pd.merge(metadata_df,task_df,left_on = 'versionId',right_on = 'versionid')
        result_db.sort_values(by="end_time", ascending=False, inplace=True)
        result_db.drop_duplicates(subset="versionid",keep="first", inplace=True)
        return send_file(
            io.BytesIO(result_db.to_csv(index=False, encoding="utf-8").encode()),
            attachment_filename=f"{project_name}.csv",
            as_attachment=True,
        )

    except BaseException as base_exception:  # pylint:disable=broad-except
        logging.exception("Excel not created: %s", base_exception)
        return "Excel not created", 400


@bp.route("/dev_run/run", methods=["POST"])
def dev_run():
    """Dev run."""

    if request.method == "POST":
        project_name = request.form.get("project_name", None)
        domain = request.form.get("domain", None)
        pdf_file = request.files["file"] or None
        config_file = request.files["config"] or None

        if not all(
            [project_name, pdf_file, config_file]
        ):  ## change to any after testing
            return jsonify(
                {
                    "message": "Either the project name, the \
                                PDF or the config JSON file is missing",
                    "status_code": 400,
                }
            )

        project_name = project_name.lower().strip()
        pdf_filename = pdf_file.filename.strip()
        config_filename = config_file.filename.strip()
        config_file = json.loads(config_file.read())

        ## Check if uploaded files are valid/allowed.
        if not all(
            [utils.allowed_file(pdf_filename), utils.allowed_file(config_filename)]
        ):
            return jsonify(
                {
                    "message": "Uploaded files are invalid.",
                    "status_code": 400,
                }
            )

        logging.info(
            "Project Name: %s, PDF Filename: %s", project_name, domain, pdf_filename
        )

        user_input_save_location = os.path.join(
            configs.S3_INPUT_SAVE_LOCATION, project_name, pdf_filename
        )

        output_folder = os.path.join(
            configs.S3_SAVE_LOCATION,
            project_name,
            pdf_filename.split(".")[0] + "_concised.pdf",
        )

        logging.info("Input save location: %s", user_input_save_location)
        logging.info("Output folder: %s", output_folder)

        ## Saving to S3
        S3Utils("LeadGeneration").save_document(
            user_input_save_location, pdf_file.read()
        )

        _, _, _ = run_pipeline(
            docpath=user_input_save_location,
            output_docfolder=output_folder,
            project_config=config_file,
            domain=domain,
        )

        ## Deleting from S3 (clean-up) [UNSTABLE]
        # S3Utils().delete(user_input_save_location)

        return "Run completed for all files", 200

    return "Invalid request", 400


# Utility endpoint for S3 related operations
@bp.route("/s3-operator", methods=["POST"])
def s3_operator():
    operator = request.form["operator"].lower()

    if operator.startswith("down"):
        try:
            filename = s3_utility_function(
                request.form["path"], TEMPFILE_DIRECTORY, operator
            )
            download_name = "_".join(filename.split("_")[1:])

            return send_from_directory(
                directory=TEMPFILE_DIRECTORY,
                path=filename,
                as_attachment=True,
                download_name=download_name,
            )
        except BaseException as e:
            print(e)
            return "Failed to fetch file from the path provided!", 400

    elif operator.startswith("up"):
        try:
            if not os.path.isdir(TEMPFILE_DIRECTORY):
                os.makedirs(TEMPFILE_DIRECTORY)
            upload_file = request.files["file"]
            save_path = os.path.join(TEMPFILE_DIRECTORY, upload_file.filename)
            upload_file.save(save_path)
            s3_uri = s3_utility_function(save_path, request.form["path"], operator)
            return s3_uri
        except BaseException as e:
            print(e)
            return "Failed to upload file!", 400

    elif operator.startswith("del"):
        try:
            path = s3_utility_function(request.form["path"], "", operator)
            return "Delete operation successful!", 200
        except BaseException as e:
            print(e)
            return "Failed to delete file!", 400

    else:
        return "Incorrect operator type passed. Please verify input and try again!", 400


@bp.route("/s3_filepaths/run", methods=["POST"])
def s3_filepaths():
    """this endpoint gets csv having version ids to get s3 filepaths which are then processed in loop in bulk run"""
    version_id_path = request.files["version_id_csv"] or None

    if not version_id_path:
        return "File not received", 400

    df = pd.read_csv(version_id_path)
    try:
        df1 = get_s3_filepaths(df)

        return send_file(
            io.BytesIO(df1.to_csv(index=False, encoding="utf-8").encode()),
            attachment_filename="s3_filepaths.csv",
            as_attachment=True,
        )

    except Exception as e:
        print(f"* Error while returning file, {e}")
        return f"Error while returning file, {e}", 400


@bp.route("/s3_getfiles/run", methods=["POST"])
def s3_getfiles():
    """this endpoint gets the s3 bucket having files to create a s3 filepath list which are then processed in loop in bulk run"""
    s3_folder = request.get_json()["s3_folder"]

    ## TODO: Make bucket selection more dynamic.
    filepath_list = S3Utils("LeadGeneration").get_file_list(s3_folder)
    df1 = pd.DataFrame(filepath_list, columns=["s3_paths"])

    # TODO: figure out better way for user to download this file
    try:
        return send_file(
            io.BytesIO(df1.to_csv(index=False, encoding="utf-8").encode()),
            attachment_filename="s3_filepaths.csv",
            as_attachment=True,
        )

    except Exception as e:
        print(f"* Error while returning file, {e}")
        return "file failed to save", 400

@bp.route("/postgres/write", methods=["POST"])
def upload_file():
    try:
        file = request.files['file']
        table_name = request.form['table_name']
        if file and table_name:
            if not os.path.isdir(TEMPFILE_DIRECTORY):
                os.makedirs(TEMPFILE_DIRECTORY)
            file_path = os.path.join(TEMPFILE_DIRECTORY, file.filename)
            file.save(file_path)
            df = pd.read_excel(file_path) if file_path.endswith('.xlsx') else pd.read_csv(file_path)
            utils.write_to_postgres(df, table_name)
            return jsonify({'message': 'File uploaded successfully and data written to the database.'})
        else:
            return jsonify({'error': 'Missing file or table_name parameter'}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 500