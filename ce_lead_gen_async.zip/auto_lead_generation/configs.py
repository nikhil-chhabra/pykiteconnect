"""Configuration for Lead Generation."""


import logging
import os
import db_utils
import re
server = 'incubator-db-2.cpx9jdg3dlsj.us-east-1.rds.amazonaws.com:5432'
password = 'HelloSpgMiNPD123!'
username = 'postgres'
db='lead_generation'
## Release version
RELEASE_VERSION = "0.0.1"

## Gunicorn config
if os.environ.get("PORT") is not None:
    PORT_CNFG = int(os.environ.get("PORT"))
else:
    PORT_CNFG = 8080

## Runtime environments.
## Expects following RUN_ENV values: 'LOCAL', 'DEV', 'TEST', 'STAGE', 'PROD'.
## If not provided, falls back to 'LOCAL'
RUN_ENVS = ("DEV", "LOCAL", "TEST", "STAGE", "PROD")
RUN_ENV = os.getenv("RUN_ENV")
if not RUN_ENV:
    RUN_ENV = "LOCAL"  ## Change to LOCAL to run locally.
logging.info("Run environment: %s", RUN_ENV)


loglevel = "debug"
DEBUG_CONFIG = True
SERVER_HOST = f"http://localhost:{PORT_CNFG}/"
REDIS_HOST = "redis://localhost:6379"

## Database
DB_NAME = "docdb-rxlead-dev"
DB_URI = "mongodb://rxlead:rxlead123@docdb-rxlead-dev.cluster-cd7bka2depgj.us-east-1.docdb.amazonaws.com:27017/?replicaSet=rs0&readPreference=secondaryPreferred&retryWrites=false"

## AWS
## TODO: Post restructuring, save to local.
S3_FLASHANNOTATE_SAVE_LOCATION = "LeadGeneration/outputs/flash_annotate"
S3_SAVE_LOCATION = "LeadGeneration/outputs/pdfs"
S3_INPUT_SAVE_LOCATION = "LeadGeneration/inputs/pdfs"
S3_HITS_SAVE_LOCATION = "LeadGeneration/outputs/hits"
f = open(r"C:\Users\nikhil_chhabra\.aws\credentials", "r")
text=f.read()
lll=re.findall('=(.*?)(?:\r?\n|$)',text)
AWS_ACCESS_KEY_ID = lll[2].strip()
AWS_SECRET_KEY_ACCESS = lll[3].strip()
AWS_SESSION_TOKEN = lll[4].strip()
BUCKET_NAME = "s3-mi-dt-rxlead-dev-us-east-1"
AWS_REGION = "us-east-1"
S3_VERSION_ID_MAP_LOCATION = "spgmi-prod-documents"
query_server="AVRPTSQLPLN.PROD.MKTINT.GLOBAL"
query_server_password="#u?ERumlpHed8AParlQo"
query_server_username="mhf\svc-sqlgeneric_iad"


## Celery configs
task1_get_request_sleep = 5
celery_broker_url = REDIS_HOST
celery_result_backend = REDIS_HOST
celery_result_expires = (
    10800  # how long to keep the results in redis backend in seconds
)
celery_task_time_limit = 7200
celery_task_acks_late = True
celery_worker_prefetch_multiplier = 1
leadgen_worker_hard_time_limit = 1200
task1_hard_time_limit = 1200
task2_hard_time_limit = 360
chain_task_hard_time_limit = 5000
# dag_gen_task_hard_time_limit = 360
# dag_update_task_hard_time_limit = 360
# dag_delete_task_hard_time_limit = 360
celery_worker_concurrency = (
    1  # be careful here, we want our long running tasks to have concurrency of 1,
)
# but for example for merge task, its better to have default concurrency (cpu count)
# because of this, we define concurrency in run.sh rather than factory.py (global)


## tasks configs
leadgen_worker_max_retries = 3
task1_max_retries = 3
task2_max_retries = 3

## compute resources
if os.environ.get("NUM_CORES") is not None:
    thread_count_cnfg = int(os.environ.get("NUM_CORES"))
else:
    thread_count_cnfg = 8
logging.info("Number of cores: %s", thread_count_cnfg)


bind = ":" + str(PORT_CNFG)
workers = thread_count_cnfg * 2 + 1
timeout = 1000
