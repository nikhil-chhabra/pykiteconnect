import json
import pandas as pd
from glob import glob
import db_utils
import os
import auto_lead_generation.configs as configs
import logging
from db_utils import S3Utils
import concurrent.futures
from auto_lead_generation.utility_functions import get_s3_filepaths

def check_and_map(pattern, my_list):
    if pattern in my_list:
        return 'yes'
    else:
        return 'no'

def get_score(df,domain):
    
    if(domain == 'Indices'):
        df_strength = df[(df['Association']=='strong')|(df['Association']=='medium')|(df['Association']=='weak')|(df['Association']=='excellent')]
        
        
        df_new = df_strength.groupby(by = ['Document Name','Association'])['Pattern'].agg(sum).reset_index()
        sortbox = {'excellent':1,'strong':2,'medium':3,'weak':4}
        df_new['sort_column'] = df_new.Association.map(sortbox)
        #  #sort with sort_column
        
        df_new = df_new.sort_values('sort_column').drop('sort_column',axis=1).reset_index(drop=True)
        score_df = df_new.groupby(by = 'Document Name').first().reset_index()
        # score_df = df_new[0:1]
        
        
        df_comp = df_new.groupby(by = ['Document Name'])['Pattern'].agg(sum).reset_index(name = 'All patterns')
        df_comp['Competitor'] = df_comp['All patterns'].apply(lambda x: check_and_map('competitor_related',x))
        score_df['Competitor'] = df_comp['Competitor']
        
        report_list = ['trademark']
        report_df = df[df['Association'].isin(report_list)]
        
        
        merge_df = pd.concat([score_df,report_df], ignore_index=True)
        merge_df_no_duplicates = merge_df.drop_duplicates(subset=['Document Name','Association'])
        merge_df_no_duplicates['Trademark_col'] = merge_df_no_duplicates['Association'].apply(lambda x: 'yes' if x == 'trademark' else 'no')
        
        merge_df_no_duplicates['Trademark'] = merge_df_no_duplicates.groupby('Document Name')['Trademark_col'].transform(lambda x: 'yes' if 'yes' in x.values else 'no')
        
        final_df = merge_df_no_duplicates[(merge_df_no_duplicates['Association']=='strong') |
                                         (merge_df_no_duplicates['Association']=='medium') |
                                          (merge_df_no_duplicates['Association']=='weak')]
        final_df = final_df[["Document Name","Association","Competitor","Trademark"]]
        score_df = final_df.copy().rename(columns={'Association': 'Lead Strength'})
                
    else:
        sortbox = {'strong':1,'medium':2,'weak':3}
    
         #create new column with the sort order
        df_strength = df[(df['Association']=='strong')|(df['Association']=='medium')|(df['Association']=='weak')]
    
    
        df_new = df_strength.groupby(by = ['Document Name','Association'])['Pattern'].agg(sum).reset_index()
        df_new['sort_column'] = df_new.Association.map(sortbox)
        #  #sort with sort_column
    
        df_new = df_new.sort_values('sort_column').drop('sort_column',axis=1).reset_index(drop=True)
        score_df = df_new.groupby(by = 'Document Name').first().reset_index()
        score_df = score_df[['Document Name','Association']]
    
    return score_df

def get_metadata(metadata_df,language_df):
    try:
        metadata = metadata_df[['CompanyName', 'companyId', 'Country',  'originalLanguageID', 'IndustryName','versionId']]
        updated_metadata = pd.merge(metadata,language_df[['languageId','languageName']],left_on = 'originalLanguageID',right_on = 'languageId')
        updated_metadata = updated_metadata.drop(columns = ['originalLanguageID','languageId'])
        return updated_metadata
    except:
        metadata_df['languageName']=""
        return metadata_df

def get_metadata_merge(score_df,updated_metadata): #this input will be provided from user to the endpoint
    score_df['Document Name']=score_df['Document Name'].apply(lambda x : str(x))
    updated_metadata['s3_paths']=updated_metadata['s3_paths'].apply(lambda x : str(x))
    meta_df = pd.merge(score_df,updated_metadata, left_on = 'Document Name',right_on = 's3_paths', how = 'left')
    meta_df = meta_df.drop(columns = ['s3_paths'])
    return meta_df   

def get_domain_excel(domain,df):
    if domain == "Commodity Insights":
        esg_df = df.groupby('Document Name')['Association'].agg(lambda x: 'Yes' if 'esg' in x.values else 'No').reset_index()
        esg_df.columns = ['Document Name', 'esg']
        merge_df= pd.merge(df,esg_df,on ="Document Name", how = "left")
    else:
        merge_df = df
    domain_excel = merge_df
    return domain_excel

def get_db_excel(final_df):
    final_df=final_df[['Document Name','CompanyName','Country','languageName','IndustryName','Association','companyId']]
    final_df = final_df.rename(columns = {'Document Name': 'document_name',
                            'CompanyName' : 'Company' ,
                            'Country' :'country' ,
                            'languageName': 'language' ,
                            'IndustryName': 'industry',
                            'Association': 'lead_strength',
                            'companyId':'companyid'})
    final_df = final_df.drop_duplicates(subset='document_name', keep="first")
    final_df['curated_document'] = 'Preview'
    final_df['user'] = "Pending"
    final_df['lead_quality'] = ""
    final_df['comment'] = ""
    final_df['document_name']=final_df['document_name'].apply(lambda x : str(x)+".pdf")
    return final_df

def json_to_df(project_name,metadata_df):
   
    excel_result = pd.DataFrame()
    project_path = "/"+ project_name 
    hits_save_path = configs.S3_HITS_SAVE_LOCATION + project_path
    metadata_df['s3_path']=metadata_df['s3_paths'].apply(lambda x : hits_save_path+"/"+str(x)+".json")
    final_hits_list  = db_utils.S3Utils().get_file_list(hits_save_path)
    final_hits_list_df=pd.DataFrame(final_hits_list,columns=["item"])
    final_hits_list_df=final_hits_list_df[final_hits_list_df['item'].isin(metadata_df['s3_path'].tolist())]
    hits_list=final_hits_list_df["item"].tolist()
    s3=S3Utils()
    with concurrent.futures.ThreadPoolExecutor() as executor:
        futures = {executor.submit(s3.read_document, key): key for key in hits_list}
        for future in concurrent.futures.as_completed(futures):
            key = futures[future]
            try:
                content = future.result()
                if content is not None:
                    try:
                        json_data = json.loads(content)
                     
                        # Decode the JSON data
                        hits = [tuple(x) for x in json_data]
                    
                        f = 0
                        for d in hits:
                            if(len(d)==11):
                                f = 1
                                break    
                        if(f==1):
                            column_names = ['Proximity', 'Document Name', 'Association', 'Pattern', 'Page', 'Block No', 'Block Type', 'x0', 'y0', 'x1', 'y1']
                            # Create a DataFrame from the flattened data with specified column names
                        else:
                            column_names = ['Proximity', 'Document Name', 'Association', 'Pattern']
                            
                        df = pd.DataFrame(hits, columns=column_names)
                        # print(f"An error occurred while processing {hits_json}: {e}")
                    
                    except Exception as e:
                        print(f"An error occurred while processing {key}: {e}")
                        
                    
                    excel_result = pd.concat([excel_result, df], ignore_index=True)
            except Exception as e:
                print(f"Error processing file {key}: {str(e)}")
        
    return excel_result

def get_excel(metadata_df,language_df,project_name,domain):
    metadata_df=get_s3_filepaths(metadata_df)
    metadata_df = get_metadata(metadata_df,language_df)
    excel_result =  json_to_df(project_name,metadata_df)
    excel_result = get_score(excel_result,domain)
    excel_result = get_metadata_merge(excel_result,metadata_df)
    domain_excel = get_domain_excel(domain,excel_result)
    final_df = get_db_excel(domain_excel)
    return final_df
