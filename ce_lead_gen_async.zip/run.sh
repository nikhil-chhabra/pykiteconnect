#!/bin/bash

if [[ $WORKER_TYPE == "'hub_worker'" ]] || [[ $WORKER_TYPE == "hub_worker" ]]  ; then
  gunicorn run:app --config=auto_lead_generation/configs.py --log-level=info

elif [[ $WORKER_TYPE == "'leadgen_worker'" ]] || [[ $WORKER_TYPE == "leadgen_worker" ]]  ; then
  celery -A celery_worker.celery worker -Ofair --concurrency=16 -Q leadgen_queue -n leadgenworker@%h --loglevel=debug

elif [[ $WORKER_TYPE == "'flower'" ]] || [[ $WORKER_TYPE == "flower" ]]; then
  celery -A celery_worker.celery flower --port=8998 --persistent=True --db=/mnt/efs/flower --state_save_interval=10000 --purge_offline_workers=7200 --loglevel=debug --tasks_columns="name,uuid,state,args,kwargs,result,received,started,runtime,worker,retries,revoked,exception,expires,eta"

elif [[ $WORKER_TYPE == "'frontend'" ]] || [[ $WORKER_TYPE == "frontend" ]]; then
  gunicorn -b 0.0.0.0:5000 --chdir /app/frontend app:app

else
  echo "Doesn't seem you passed WORKER_TYPE env variable, running the hub only ..." &
  gunicorn run:app --config=auto_lead_generation/configs.py
fi

# running it in windows: celery -A celery_worker.celery worker -O fair -Q scraper_queue -P gevent
# flower: celery -A celery_worker.celery flower --port=5555
