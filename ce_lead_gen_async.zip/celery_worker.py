"""Initializes Celery for Auto Lead Generation."""


from auto_lead_generation import celery
from auto_lead_generation.factory import create_app
from auto_lead_generation.celery_utils import init_celery

app = create_app()
init_celery(celery, app)
