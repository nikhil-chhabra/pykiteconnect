"""Database I/O functions."""


import os

import boto3
from botocore.client import Config

import auto_lead_generation.configs as configs
import logging


class S3Utils:
    """Utilities for S3 I/O.

    Current directory saving structure:

    Input PDFs saved as: inputs/pdfs/project_name/pdf_file
    Generated Hits JSON saved as: inputs/hits/project_name/json
    Output PDFs saved as: outputs/project_name/concised_pdf

    Note: Periodic cleanup will be needed to remove input files.
    """

    def __init__(self, bucket_name="LeadGeneration"):
        """Initialize S3 with credentials."""

        self.bucket_name = bucket_name

        self.bucket_name = (
            configs.BUCKET_NAME
            if bucket_name == "LeadGeneration"
            else configs.S3_VERSION_ID_MAP_LOCATION
        )

        session = boto3.Session(
            aws_access_key_id=configs.AWS_ACCESS_KEY_ID,
            aws_secret_access_key=configs.AWS_SECRET_KEY_ACCESS,
            region_name=configs.AWS_REGION
        )

        config = Config(connect_timeout=60, read_timeout=70)
        self.s_3 = session.resource("s3", config=config)
        self.s3_bucket = self.s_3.Bucket(self.bucket_name)

        self.AWS_ACCESS_KEY_ID = configs.AWS_ACCESS_KEY_ID

        if configs.AWS_ACCESS_KEY_ID is None:
            self.ids = (
                'id="'
                + configs.canonical_id_mi_content
                + '",id="'
                + configs.canonical_id_mi_internal
                + '"'
            )

    def save_to_s3(self, doc, pdf_filename, output_docfolder):
        """Saves file to S3."""

        print("Saving to %s", output_docfolder)
        renamed_file = pdf_filename.split(".")[0] + "_concised.pdf"
        print("Renamed file: %s", renamed_file)
        save_path = os.path.join(output_docfolder, renamed_file)

        if self.check_if_exists(save_path):
            print(f"File {save_path} already exists, not saving..")
            return

        print("Save path: %s", save_path)
        self.s3_bucket.put_object(Key=save_path, Body=doc.write())

    def save_document(self, save_path, document):
        """Saves document to S3 (generalized)."""
        if self.AWS_ACCESS_KEY_ID is None:
            self.s3_bucket.Object(save_path).put(
                Body=document, GrantFullControl=self.ids
            )
        else:
            self.s3_bucket.Object(save_path).put(Body=document)

    def read_document(self, document_path):
        """Reads document from S3."""

        try:
            pdf_filename = os.path.basename(document_path)
            print("Document name before reading from S3: ", pdf_filename)
            pdf_document = (
                    self.s_3.Object(self.bucket_name, document_path).get()["Body"].read()
                )
            return pdf_document

        ## TODO: Return dict of results for logging (ex, return {"status": False, "message": e})
        except Exception as e:
            print(f"* Error while reading file from S3 bucket {self.bucket_name}, {e}")
            return None

    def download_to_user(self, document_path):
        """Downloads from S3 (almost a duplicate function of read_document)."""
        pdf_filename = os.path.basename(document_path)
        print("Document name before reading from S3: ", pdf_filename)

        pdf_document = self.s_3.Object(configs.BUCKET_NAME, document_path).get()["Body"]
        return pdf_document

    def download_from_s3(self, file_path, download_path):
        """Funciton to download a file from S3"""

        # Get file path from URI
        if file_path.startswith("s3:"):
            file_path = file_path.split(self.bucket_name + "/")[1]

        # Download file
        self.s3_bucket.download_file(Key=file_path, Filename=download_path)

        return

    def check_if_exists(self, key):
        """Checks if a file already exists in S3, if yes then skips saving."""
        try:
            self.s_3.Object(configs.BUCKET_NAME, key).load()
            return True
        except Exception:  ## pylint:disable=broad-except
            return False

    def delete(self, file_path):
        """Deletes a file."""
        self.s_3.meta.client.delete_object(Bucket=self.bucket_name, Key=file_path)

    def get_file_list(self, path):
        """Function to get list of all files in a dir of S3"""
        objs = list(self.s3_bucket.objects.filter(Prefix=path))
        return [str(obj.key) for obj in objs]
